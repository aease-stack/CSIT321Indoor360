import SwiftUI

@main
struct IndoorNavApp: App {
    var body: some Scene {
        WindowGroup {
            VenuePickerView()   // first screen
        }
    }
}
