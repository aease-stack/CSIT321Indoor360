import SwiftUI

struct VenuePickerView: View {
    private let store = LocalBundleIMDFStore()
    @State private var venues: [IMDFVenueMeta] = []
    @State private var errorText: String?

    var body: some View {
        NavigationStack {
            List(venues, id: \.id) { meta in
                NavigationLink(meta.name) {
                    MapRouteView(venueId: meta.id, venueName: meta.name)
                }
            }
            .navigationTitle("IMDF Venues")
            .task {
                venues = store.list()
                if venues.isEmpty {
                    errorText = "No venues found. Add a blue folder IMDFVenues with venue subfolders to the app bundle."
                }
            }
            .alert("Info",
                   isPresented: Binding(get: { errorText != nil }, set: { _ in errorText = nil })) {
                Button("OK", role: .cancel) { }
            } message: { Text(errorText ?? "") }
        }
    }
}
