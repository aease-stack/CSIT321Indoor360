import Foundation

final class GraphBuilder {
    func buildGraph(venue: IMDFVenue) -> IndoorGraph {
        var g = IndoorGraph()
        for u in venue.units {
            g.addNode(IndoorGraphNode(id: u.id, levelId: u.levelId, position: u.centroid))
        }

        // Same-level via Openings
        for o in venue.openings {
            let ids = o.unitIds
            guard ids.count >= 2 else { continue }
            for i in 0..<(ids.count - 1) {
                if let a = g.nodes[ids[i]], let b = g.nodes[ids[i+1]], a.levelId == b.levelId {
                    g.addUndirectedEdge(a.id, b.id, cost: dist(a.position, b.position))
                }
            }
        }

        // Cross-level via Transitions
        for t in venue.transitions {
            let ids = t.unitIds
            guard ids.count >= 2 else { continue }
            for i in 0..<(ids.count - 1) {
                if let a = g.nodes[ids[i]], let b = g.nodes[ids[i+1]] {
                    g.addUndirectedEdge(a.id, b.id, cost: dist(a.position, b.position) * 1.2)
                }
            }
        }

        // Fallback proximity for orphans
        let ids = Array(g.nodes.keys)
        for id in ids where (g.edges[id]?.isEmpty ?? true) {
            if let n = g.nodes[id] {
                let nearest = ids.compactMap { g.nodes[$0] }
                    .filter { $0.id != id && $0.levelId == n.levelId }
                    .map { ($0.id, dist(n.position, $0.position)) }
                    .sorted { $0.1 < $1.1 }
                    .first
                if let nn = nearest, nn.1 < 3.0 {
                    g.addUndirectedEdge(id, nn.0, cost: nn.1)
                }
            }
        }
        return g
    }

    private func dist(_ a: IMDFPoint, _ b: IMDFPoint) -> Double {
        let dx = a.x - b.x, dy = a.y - b.y
        return (dx*dx + dy*dy).squareRoot()
    }
}
