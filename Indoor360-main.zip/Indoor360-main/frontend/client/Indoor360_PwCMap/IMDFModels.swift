import Foundation
import simd

public struct IMDFPoint: Hashable, Codable { public var x: Double; public var y: Double }
public struct IMDFPolygon: Hashable { public let outer: [IMDFPoint]; public let holes: [[IMDFPoint]] }

public struct IMDFAnchor: Hashable { public let id: String; public let name: String?; public let point: IMDFPoint }
public struct IMDFLevel: Hashable { public let id: String; public let name: String?; public let ordinal: Int }

public struct IMDFUnit: Hashable {
    public let id: String
    public let name: String?
    public let levelId: String?
    public let centroid: IMDFPoint
    public let polygons: [IMDFPolygon]
}

public struct IMDFOpening: Hashable {
    public let id: String
    public let unitIds: [String]
    public let centroid: IMDFPoint?
    public let lines: [[IMDFPoint]]          // LineString/MultiLineString
}

public struct IMDFTransition: Hashable {
    public let id: String
    public let unitIds: [String]
    public let centroid: IMDFPoint?
    public let levelIds: [String]
}

public struct IMDFFixture: Hashable {
    public let id: String
    public let name: String?
    public let category: String?
    public let point: IMDFPoint?             // if Point
    public let polygons: [IMDFPolygon]       // if Polygon/MultiPolygon
    public let lines: [[IMDFPoint]]          // if LineString/MultiLineString
}

public struct IMDFVenue: Hashable {
    public let id: UUID
    public let name: String
    public let levels: [IMDFLevel]
    public let units: [IMDFUnit]
    public let openings: [IMDFOpening]
    public let transitions: [IMDFTransition]
    public let anchors: [IMDFAnchor]
    public let fixtures: [IMDFFixture]
    public let folderURL: URL
}
