import SwiftUI
import MapKit

struct MapKitMapViewRepresentable: UIViewRepresentable {
    var units: [IMDFUnit]
    var openings: [IMDFOpening]
    var fixtures: [IMDFFixture]
    @Binding var selectedUnit: IMDFUnit?

    final class Coordinator: NSObject, MKMapViewDelegate {
        var parent: MapKitMapViewRepresentable
        var polygonRenderers: [MKPolygon: MKPolygonRenderer] = [:]
        var overlayToUnit: [MKPolygon: IMDFUnit] = [:]
        init(_ parent: MapKitMapViewRepresentable) { self.parent = parent }

        @objc func handleTap(_ gr: UITapGestureRecognizer) {
            guard let map = gr.view as? MKMapView else { return }
            let pt = gr.location(in: map)
            let mp = MKMapPoint(map.convert(pt, toCoordinateFrom: map))
            for (poly, renderer) in polygonRenderers {
                let p = renderer.point(for: mp)
                if renderer.path.contains(p), let unit = overlayToUnit[poly] {
                    parent.selectedUnit = unit
                    map.setNeedsDisplay()
                    return
                }
            }
        }

        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let poly = overlay as? MKPolygon {
                let r = MKPolygonRenderer(polygon: poly)
                if let unit = overlayToUnit[poly] {
                    // UNIT polygon
                    if unit.id == parent.selectedUnit?.id {
                        r.fillColor = UIColor.systemGreen.withAlphaComponent(0.45)
                    } else {
                        r.fillColor = UIColor.systemGray2.withAlphaComponent(0.35)
                    }
                    r.strokeColor = UIColor.label.withAlphaComponent(0.25)
                    r.lineWidth = 1.0
                } else {
                    // FIXTURE polygon
                    r.fillColor = UIColor.systemPurple.withAlphaComponent(0.35)
                    r.strokeColor = UIColor.systemPurple.withAlphaComponent(0.8)
                    r.lineWidth = 1.0
                }
                polygonRenderers[poly] = r
                return r
            } else if let line = overlay as? MKPolyline {
                let r = MKPolylineRenderer(polyline: line)
                switch overlay.title ?? "" {
                case "opening": r.strokeColor = UIColor.systemOrange; r.lineWidth = 3
                default:        r.strokeColor = UIColor.systemPurple; r.lineWidth = 2
                }
                r.lineCap = .round
                return r
            } else if let circle = overlay as? MKCircle {
                let r = MKCircleRenderer(circle: circle)
                r.fillColor = (overlay.title ?? "") == "fixture" ? UIColor.systemPurple : UIColor.systemOrange
                return r
            }
            return MKOverlayRenderer(overlay: overlay)
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> MKMapView {
        let map = MKMapView()
        map.delegate = context.coordinator
        map.pointOfInterestFilter = .excludingAll
        map.isRotateEnabled = false
        map.isPitchEnabled = false
        map.addGestureRecognizer(UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTap(_:))))
        redraw(map, context: context)
        return map
    }

    func updateUIView(_ uiView: MKMapView, context: Context) {
        redraw(uiView, context: context)
    }

    // Build overlays
    private func redraw(_ map: MKMapView, context: Context) {
        let c = context.coordinator
        c.overlayToUnit.removeAll(); c.polygonRenderers.removeAll()
        map.removeOverlays(map.overlays); map.removeAnnotations(map.annotations)

        var union = MKMapRect.null

        // Units -> polygons (with holes)
        for u in units {
            if u.polygons.isEmpty {
                let circle = MKCircle(center: coord(u.centroid), radius: 2)
                map.addOverlay(circle); union = union.union(circle.boundingMapRect)
            } else {
                for poly in u.polygons {
                    guard poly.outer.count >= 3 else { continue }
                    var holes: [MKPolygon] = []
                    for h in poly.holes where h.count >= 3 {
                        holes.append(MKPolygon(coordinates: coords(h), count: h.count))
                    }
                    let mk = MKPolygon(coordinates: coords(poly.outer), count: poly.outer.count, interiorPolygons: holes)
                    c.overlayToUnit[mk] = u
                    map.addOverlay(mk)
                    union = union.union(mk.boundingMapRect)
                }
            }
        }

        // Openings -> polylines (orange)
        for o in openings {
            for line in o.lines where line.count >= 2 {
                let pl = MKPolyline(coordinates: coords(line), count: line.count)
                pl.title = "opening"
                map.addOverlay(pl)
                union = union.union(pl.boundingMapRect)
            }
            if o.lines.isEmpty, let cpt = o.centroid {
                let circ = MKCircle(center: coord(cpt), radius: 1.0)
                circ.title = "opening"
                map.addOverlay(circ)
                union = union.union(circ.boundingMapRect)
            }
        }

        // Fixtures -> polygons / lines / points (purple)
        for f in fixtures {
            for poly in f.polygons {
                guard poly.outer.count >= 3 else { continue }
                var holes: [MKPolygon] = []
                for h in poly.holes where h.count >= 3 {
                    holes.append(MKPolygon(coordinates: coords(h), count: h.count))
                }
                let mk = MKPolygon(coordinates: coords(poly.outer), count: poly.outer.count, interiorPolygons: holes)
                map.addOverlay(mk)
                union = union.union(mk.boundingMapRect)
            }
            for line in f.lines where line.count >= 2 {
                let pl = MKPolyline(coordinates: coords(line), count: line.count)
                pl.title = "fixture-line"
                map.addOverlay(pl)
                union = union.union(pl.boundingMapRect)
            }
            if let p = f.point {
                let circ = MKCircle(center: coord(p), radius: 0.8)
                circ.title = "fixture"
                map.addOverlay(circ)
                union = union.union(circ.boundingMapRect)
            }
        }

        if !union.isNull && union.size.width > 0 && union.size.height > 0 {
            map.setVisibleMapRect(union, edgePadding: UIEdgeInsets(top: 80, left: 20, bottom: 20, right: 20), animated: false)
        }
    }

    // Helpers
    private func coord(_ p: IMDFPoint) -> CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: p.y, longitude: p.x) // IMDF is [lon, lat]
    }
    private func coords(_ pts: [IMDFPoint]) -> [CLLocationCoordinate2D] {
        pts.map { coord($0) }
    }
}
