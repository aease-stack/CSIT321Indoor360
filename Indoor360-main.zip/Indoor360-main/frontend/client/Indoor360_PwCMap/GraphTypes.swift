public struct IndoorGraphNode: Hashable {
    public let id: String
    public let levelId: String?
    public let position: IMDFPoint
}
public struct IndoorGraphEdge: Hashable { public let from: String; public let to: String; public let cost: Double }

public struct IndoorGraph {
    public var nodes: [String: IndoorGraphNode] = [:]
    public var edges: [String: [IndoorGraphEdge]] = [:]
    public mutating func addNode(_ n: IndoorGraphNode) { nodes[n.id] = n; edges[n.id] = edges[n.id] ?? [] }
    public mutating func addUndirectedEdge(_ a: String, _ b: String, cost: Double) {
        guard nodes[a] != nil, nodes[b] != nil else { return }
        edges[a, default: []].append(IndoorGraphEdge(from: a, to: b, cost: cost))
        edges[b, default: []].append(IndoorGraphEdge(from: b, to: a, cost: cost))
    }
}
