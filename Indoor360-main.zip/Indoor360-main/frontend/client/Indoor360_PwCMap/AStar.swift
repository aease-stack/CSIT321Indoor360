import Foundation

public final class AStar {
    public struct Result {
        public let path: [String]
        public let distance: Double
    }

    public func findPath(graph g: IndoorGraph, start: String, goal: String) -> Result? {
        guard g.nodes[start] != nil, g.nodes[goal] != nil else { return nil }

        func h(_ a: String, _ b: String) -> Double {
            guard let na = g.nodes[a], let nb = g.nodes[b] else { return 0 }
            let dx = na.position.x - nb.position.x
            let dy = na.position.y - nb.position.y
            return (dx*dx + dy*dy).squareRoot()
        }

        var open: Set<String> = [start]
        var cameFrom: [String: String] = [:]
        var gScore: [String: Double] = [start: 0]
        var fScore: [String: Double] = [start: h(start, goal)]

        while let current = open.min(by: { (fScore[$0] ?? .infinity) < (fScore[$1] ?? .infinity) }) {
            if current == goal {
                var path = [current]
                var c = current
                while let p = cameFrom[c] {
                    path.append(p)
                    c = p
                }
                return Result(path: path.reversed(), distance: gScore[current] ?? 0)
            }
            open.remove(current)
            for e in g.edges[current] ?? [] {
                let tentative = (gScore[current] ?? .infinity) + e.cost
                if tentative < (gScore[e.to] ?? .infinity) {
                    cameFrom[e.to] = current
                    gScore[e.to] = tentative
                    fScore[e.to] = tentative + h(e.to, goal)
                    open.insert(e.to)
                }
            }
        }
        return nil
    }
}
