import Foundation
import UIKit
import CryptoKit

public struct IMDFVenueMeta: Hashable {
    public let id: UUID
    public let name: String
    public let folderURL: URL
}

protocol IMDFStore {
    func list() -> [IMDFVenueMeta]
    func load(id: UUID) throws -> IMDFVenue
}

final class LocalBundleIMDFStore: IMDFStore {
    func list() -> [IMDFVenueMeta] {
        guard let bundleRoot = Bundle.main.resourceURL else { return [] }
        var metas: [IMDFVenueMeta] = []
        let fm = FileManager.default

        func dirIsIMDF(_ dir: URL) -> Bool {
            guard let entries = try? fm.contentsOfDirectory(atPath: dir.path) else { return false }
            let names = Set(entries.map { $0.lowercased() })
            return names.contains(where: { $0.contains("unit.geojson") }) &&
                   names.contains(where: { $0.contains("level.geojson") })
        }
        func collect(in dir: URL, depth: Int = 0) {
            guard depth <= 3,
                  let urls = try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]) else { return }
            for u in urls {
                if ((try? u.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false) {
                    if dirIsIMDF(u) {
                        metas.append(IMDFVenueMeta(id: deterministicUUID(from: u.path), name: u.lastPathComponent, folderURL: u))
                    } else { collect(in: u, depth: depth + 1) }
                }
            }
        }
        if let imdfRoot = Bundle.main.url(forResource: "IMDFVenues", withExtension: nil) {
            collect(in: imdfRoot)
        } else {
            collect(in: bundleRoot)
        }
        var seen = Set<String>()
        return metas.filter { seen.insert($0.folderURL.path).inserted }.sorted { $0.name < $1.name }
    }

    func load(id: UUID) throws -> IMDFVenue {
        guard let meta = list().first(where: { $0.id == id }) else { throw IMDFLoaderError.parseFailed("Venue meta not found.") }
        return try IMDFLoader().importPackage(from: meta.folderURL, forcedName: meta.name, forcedId: meta.id)
    }

    private func deterministicUUID(from s: String) -> UUID {
        let b = Array(SHA256.hash(data: Data(s.utf8)))
        let u = uuid_t(b[0],b[1],b[2],b[3],b[4],b[5],b[6],b[7],b[8],b[9],b[10],b[11],b[12],b[13],b[14],b[15])
        return UUID(uuid: u)
    }
}

// MARK: - Loader

enum IMDFLoaderError: Error, LocalizedError {
    case notDirectory
    case fileMissing(String)
    case parseFailed(String)
    var errorDescription: String? {
        switch self {
        case .notDirectory: return "Selected IMDF path is not a directory."
        case .fileMissing(let f): return "Missing required IMDF file: \(f)"
        case .parseFailed(let why): return "Failed to parse IMDF: \(why)"
        }
    }
}

final class IMDFLoader {
    func importPackage(from folderURL: URL, forcedName: String? = nil, forcedId: UUID? = nil) throws -> IMDFVenue {
        var isDir: ObjCBool = false
        guard FileManager.default.fileExists(atPath: folderURL.path, isDirectory: &isDir), isDir.boolValue
        else { throw IMDFLoaderError.notDirectory }

        func find(_ needle: String) -> URL? {
            let e = FileManager.default.enumerator(at: folderURL, includingPropertiesForKeys: nil)
            while let u = e?.nextObject() as? URL { if u.lastPathComponent.lowercased().contains(needle) { return u } }
            return nil
        }

        guard let levelURL = find("level.geojson") else { throw IMDFLoaderError.fileMissing("level.geojson") }
        guard let unitURL  = find("unit.geojson")  else { throw IMDFLoaderError.fileMissing("unit.geojson") }
        let openingURL    = find("opening.geojson")
        let transitionURL = find("transition.geojson")
        let anchorURL     = find("anchor.geojson")
        let fixtureURL    = find("fixture.geojson")

        let levels      = try parseLevels(levelURL)
        let units       = try parseUnits(unitURL)
        let openings    = (try? parseOpenings(openingURL)) ?? []
        let transitions = (try? parseTransitions(transitionURL)) ?? []
        let anchors     = (try? parseAnchors(anchorURL)) ?? []
        let fixtures    = (try? parseFixtures(fixtureURL)) ?? []

        return IMDFVenue(
            id: forcedId ?? UUID(),
            name: forcedName ?? folderURL.lastPathComponent,
            levels: levels,
            units: units,
            openings: openings,
            transitions: transitions,
            anchors: anchors,
            fixtures: fixtures,
            folderURL: folderURL
        )
    }

    // MARK: JSON helper
    private func json(_ url: URL?) throws -> [String: Any] {
        guard let url = url else { throw IMDFLoaderError.fileMissing("Unknown") }
        let data = try Data(contentsOf: url)
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw IMDFLoaderError.parseFailed("Invalid JSON at \(url.lastPathComponent)")
        }
        return obj
    }

    // MARK: Parsers

    private func parseLevels(_ url: URL) throws -> [IMDFLevel] {
        let root = try json(url)
        let features = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFLevel] = []
        for f in features {
            let props = (f["properties"] as? [String: Any]) ?? [:]
            let id = (f["id"] as? String) ?? (props["id"] as? String) ?? UUID().uuidString
            let ordinal = (props["ordinal"] as? Int) ?? (props["level_index"] as? Int) ?? (props["z_index"] as? Int) ?? 0
            let name = (props["name"] as? String) ?? (props["displayName"] as? String)
            out.append(IMDFLevel(id: id, name: name, ordinal: ordinal))
        }
        return out.sorted { $0.ordinal < $1.ordinal }
    }

    private func parseUnits(_ url: URL) throws -> [IMDFUnit] {
        let root = try json(url)
        let features = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFUnit] = []
        for f in features {
            let props = (f["properties"] as? [String: Any]) ?? [:]
            let id = (f["id"] as? String) ?? (props["id"] as? String) ?? UUID().uuidString
            let name = (props["name"] as? String) ?? (props["displayName"] as? String)
            let levelId = (props["level_id"] as? String) ?? (props["levelId"] as? String) ?? (props["level"] as? String)
            let centroid = centroidFromGeometry(f["geometry"])
            let polygons = polygonsFromGeometry(f["geometry"])
            out.append(IMDFUnit(id: id, name: name, levelId: levelId, centroid: centroid, polygons: polygons))
        }
        return out
    }

    private func parseOpenings(_ url: URL?) throws -> [IMDFOpening] {
        guard let url = url else { return [] }
        let root = try json(url)
        let feats = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFOpening] = []
        for f in feats {
            let props = (f["properties"] as? [String: Any]) ?? [:]
            let id = (f["id"] as? String) ?? (props["id"] as? String) ?? UUID().uuidString
            let unitIds = (props["unit_ids"] as? [String]) ?? (props["units"] as? [String]) ?? (props["spaces"] as? [String]) ?? (props["connects"] as? [String]) ?? []
            let lines = linesFromGeometry(f["geometry"])
            let centroid = centroidFromGeometry(f["geometry"])
            out.append(IMDFOpening(id: id, unitIds: unitIds, centroid: centroid, lines: lines))
        }
        return out
    }

    private func parseTransitions(_ url: URL?) throws -> [IMDFTransition] {
        guard let url = url else { return [] }
        let root = try json(url)
        let feats = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFTransition] = []
        for f in feats {
            let props = (f["properties"] as? [String: Any]) ?? [:]
            let id = (f["id"] as? String) ?? (props["id"] as? String) ?? UUID().uuidString
            let unitIds = (props["unit_ids"] as? [String]) ?? (props["units"] as? [String]) ?? (props["spaces"] as? [String]) ?? []
            let levelIds = (props["level_ids"] as? [String]) ?? (props["levels"] as? [String]) ?? []
            out.append(IMDFTransition(id: id, unitIds: unitIds, centroid: centroidFromGeometry(f["geometry"]), levelIds: levelIds))
        }
        return out
    }

    private func parseAnchors(_ url: URL?) throws -> [IMDFAnchor] {
        guard let url = url else { return [] }
        let root = try json(url)
        let feats = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFAnchor] = []
        for f in feats {
            let props = (f["properties"] as? [String: Any]) ?? [:]
            let id = (f["id"] as? String) ?? (props["id"] as? String) ?? UUID().uuidString
            let name = (props["name"] as? String) ?? (props["displayName"] as? String)
            out.append(IMDFAnchor(id: id, name: name, point: pointFromGeometry(f["geometry"])))
        }
        return out
    }

    private func parseFixtures(_ url: URL?) throws -> [IMDFFixture] {
        guard let url = url else { return [] }
        let root = try json(url)
        let feats = (root["features"] as? [[String: Any]]) ?? []
        var out: [IMDFFixture] = []
        for f in feats {
            let props = (f["properties"] as? [String: Any]) ?? [:]
            let id = (f["id"] as? String) ?? (props["id"] as? String) ?? UUID().uuidString
            let name = (props["name"] as? String) ?? (props["displayName"] as? String)
            let category = (props["category"] as? String) ?? (props["type"] as? String) ?? (props["class"] as? String)

            let geom = f["geometry"] as? [String: Any]
            let type = (geom?["type"] as? String) ?? ""

            var point: IMDFPoint? = nil
            var polygons: [IMDFPolygon] = []
            var lines: [[IMDFPoint]] = []

            switch type {
            case "Point":
                point = pointFromGeometry(geom)
            case "Polygon", "MultiPolygon":
                polygons = polygonsFromGeometry(geom)
            case "LineString", "MultiLineString":
                lines = linesFromGeometry(geom)
            default:
                point = centroidFromGeometry(geom)
            }

            out.append(IMDFFixture(id: id, name: name, category: category, point: point, polygons: polygons, lines: lines))
        }
        return out
    }

    // MARK: Geometry helpers

    private func pointFromGeometry(_ geomAny: Any?) -> IMDFPoint {
        guard let geom = geomAny as? [String: Any], let type = geom["type"] as? String else {
            return IMDFPoint(x: 0, y: 0)
        }
        if type == "Point", let c = geom["coordinates"] as? [Double], c.count >= 2 {
            return IMDFPoint(x: c[0], y: c[1])
        }
        return centroidFromGeometry(geomAny)
    }

    private func linesFromGeometry(_ geomAny: Any?) -> [[IMDFPoint]] {
        guard let geom = geomAny as? [String: Any], let type = geom["type"] as? String else { return [] }
        func toPts(_ arr: [[Double]]) -> [IMDFPoint] {
            arr.compactMap { $0.count >= 2 ? IMDFPoint(x: $0[0], y: $0[1]) : nil }
        }
        switch type {
        case "LineString":
            if let arr = geom["coordinates"] as? [[Double]] { return [toPts(arr)] }
        case "MultiLineString":
            if let arr = geom["coordinates"] as? [[[Double]]] { return arr.map { toPts($0) } }
        default: break
        }
        return []
    }

    private func polygonsFromGeometry(_ geomAny: Any?) -> [IMDFPolygon] {
        guard let geom = geomAny as? [String: Any], let type = geom["type"] as? String else { return [] }
        func toRing(_ raw: [[Double]]) -> [IMDFPoint] {
            raw.compactMap { $0.count >= 2 ? IMDFPoint(x: $0[0], y: $0[1]) : nil }
        }
        switch type {
        case "Polygon":
            if let rings = geom["coordinates"] as? [[[Double]]], let outerRaw = rings.first {
                let outer = toRing(outerRaw)
                let holes = Array(rings.dropFirst()).map { toRing($0) }
                return [IMDFPolygon(outer: outer, holes: holes)]
            }
        case "MultiPolygon":
            if let polys = geom["coordinates"] as? [[[[Double]]]] {
                return polys.compactMap { rings in
                    guard let outerRaw = rings.first else { return nil }
                    let outer = toRing(outerRaw)
                    let holes = Array(rings.dropFirst()).map { toRing($0) }
                    return IMDFPolygon(outer: outer, holes: holes)
                }
            }
        default: break
        }
        return []
    }

    private func centroidFromGeometry(_ geomAny: Any?) -> IMDFPoint {
        guard let geom = geomAny as? [String: Any], let type = geom["type"] as? String else { return IMDFPoint(x: 0, y: 0) }
        switch type {
        case "Polygon":
            if let rings = geom["coordinates"] as? [[[Double]]], let outer = rings.first { return average(outer) }
        case "MultiPolygon":
            if let polys = geom["coordinates"] as? [[[[Double]]]], let first = polys.first, let outer = first.first { return average(outer) }
        case "LineString":
            if let arr = geom["coordinates"] as? [[Double]] { return average(arr) }
        case "MultiLineString":
            if let arr = geom["coordinates"] as? [[[Double]]], let first = arr.first { return average(first) }
        case "Point":
            if let c = geom["coordinates"] as? [Double], c.count >= 2 { return IMDFPoint(x: c[0], y: c[1]) }
        default: break
        }
        return IMDFPoint(x: 0, y: 0)
    }

    private func average(_ arr: [[Double]]) -> IMDFPoint {
        guard !arr.isEmpty else { return IMDFPoint(x: 0, y: 0) }
        var sx = 0.0, sy = 0.0
        for p in arr where p.count >= 2 { sx += p[0]; sy += p[1] }
        let n = Double(arr.count)
        return IMDFPoint(x: sx/n, y: sy/n)
    }
}
