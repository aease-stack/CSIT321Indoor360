import SwiftUI

struct MapRouteView: View {
    let venueId: UUID
    let venueName: String

    @State private var units: [IMDFUnit] = []
    @State private var openings: [IMDFOpening] = []
    @State private var fixtures: [IMDFFixture] = []
    @State private var selectedUnit: IMDFUnit?
    @State private var errorText: String?

    private let store = LocalBundleIMDFStore()

    var body: some View {
        ZStack(alignment: .top) {
            MapKitMapViewRepresentable(
                units: units,
                openings: openings,
                fixtures: fixtures,
                selectedUnit: $selectedUnit
            )
            .ignoresSafeArea(edges: .bottom)

            VStack(spacing: 4) {
                Text(venueName).font(.headline)
                Text(selectedUnit?.name ?? "Tap a room to see its name")
                    .font(.subheadline).foregroundStyle(.secondary)
                Text("units: \(units.count) • openings: \(openings.count) • fixtures: \(fixtures.count)")
                    .font(.caption2).foregroundStyle(.tertiary)
            }
            .padding(.top, 8)
        }
        .navigationBarTitleDisplayMode(.inline)
        .task {
            do {
                let v = try store.load(id: venueId)
                units = v.units
                openings = v.openings
                fixtures = v.fixtures
            } catch { errorText = error.localizedDescription }
        }
        .alert("Load Failed",
               isPresented: Binding(get: { errorText != nil }, set: { _ in errorText = nil })) {
            Button("OK", role: .cancel) { }
        } message: { Text(errorText ?? "") }
    }
}
