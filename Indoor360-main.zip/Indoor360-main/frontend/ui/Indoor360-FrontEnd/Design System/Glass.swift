import SwiftUI

/// Reusable "frosted glass" surface with rounded-2xl corners and soft shadow.
/// Automatically respects Reduce Transparency by falling back to an opaque surface.
extension View {
    func glassBackground(
        cornerRadius: CGFloat = 24,
        shadowOpacity: Double = 0.12,
        shadowRadius: CGFloat = 16,
        shadowY: CGFloat = 6
    ) -> some View {
        background(
            Group {
                if UIAccessibility.isReduceTransparencyEnabled {
                    DSColor.surface.opacity(0.98)
                } else {
                    // Wrap Material in a View so both branches are Views
                    Color.clear.background(.ultraThinMaterial)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .shadow(color: Color.black.opacity(shadowOpacity), radius: shadowRadius, y: shadowY)
        )
    }
}
