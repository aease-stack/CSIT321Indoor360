import SwiftUI

/// PwC-inspired typography system with Dynamic Type support.
/// Uses rounded design for friendliness, bold weights for clarity.
/// Always respects user's font size preferences (Dynamic Type).
enum Typography {
    // Extra-large headlines (welcome screens, hero banners)
    static let headlineXL = Font.system(.largeTitle, design: .rounded)
        .weight(.bold)

    // Large section titles (e.g., "Sign In", "Profile")
    static let headlineL = Font.system(.title, design: .rounded)
        .weight(.semibold)

    // Medium section titles (cards, smaller sections)
    static let headlineM = Font.system(.title3, design: .rounded)
        .weight(.semibold)

    // Body text (main content)
    static let body = Font.system(.body, design: .rounded)
        .weight(.regular)

    // Body emphasis (for clickable links like "Continue as Guest")
    static let bodyEmphasis = Font.system(.body, design: .rounded)
        .weight(.semibold)

    // Caption text (helper text, error messages, small labels)
    static let caption = Font.system(.caption, design: .rounded)
        .weight(.regular)

    // Caption emphasis (important notes, badges)
    static let captionEmphasis = Font.system(.caption, design: .rounded)
        .weight(.semibold)
    
    // --- Backwards-compatibility aliases (keep old code compiling) ---
    static let titleXL = headlineXL
    static let titleL  = headlineL
    static let titleM  = headlineM
}
