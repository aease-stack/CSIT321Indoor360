import SwiftUI

// MARK: - Design System Colors

/// PwC Middle East inspired palette + app surfaces
enum DSBrand {
    static let orange = Color(hex: 0xFF6F00)
}

// Keep your other DSColor entries as-is.
// Replace the two text colors with dynamic system colors:
enum DSColor {
    static var textPrimary: Color   { Color.primary }   // adapts to light/dark
    static var textSecondary: Color { Color.secondary } // adapts to light/dark

    static let accent  = DSBrand.orange
    static let background = Color.clear   // you now use AppBackgroundView()
    static let surface    = Color(UIColor.secondarySystemBackground)
    static let success    = Color(hex: 0x2E7D32)
    static let warning    = Color(hex: 0xED6C02)
    static let danger     = Color(hex: 0xD32F2F)
}

/// Background gradients used by AppBackgroundView
enum DSGradient {
    // Light
    static let backgroundLightTop    = Color(hex: 0xFFF6ED)   // warm tint
    static let backgroundLightBottom = Color(hex: 0xFFFFFF)

    // Dark
    static let backgroundDarkTop     = Color(hex: 0x0B0B0B)
    static let backgroundDarkBottom  = Color(hex: 0x141414)

    /// Primary app background gradient for current mode
    static func appBackground(_ scheme: ColorScheme) -> LinearGradient {
        let colors = (scheme == .dark)
        ? [backgroundDarkTop, backgroundDarkBottom]
        : [backgroundLightTop, backgroundLightBottom]
        return LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    /// Subtle accent glow (optional overlay in hero areas)
    static func accentGlow(_ scheme: ColorScheme) -> RadialGradient {
        let c = DSBrand.orange.opacity(scheme == .dark ? 0.16 : 0.12)
        return RadialGradient(colors: [c, .clear],
                              center: .topLeading,
                              startRadius: 8, endRadius: 280)
    }
}

// MARK: - Color helpers

extension Color {
    /// Initialize with hex string like "#FF6F00" or "FF6F00"
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default: (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(.sRGB,
                  red: Double(r) / 255,
                  green: Double(g) / 255,
                  blue: Double(b) / 255,
                  opacity: Double(a) / 255)
    }

    /// Initialize with 0xRRGGBB
    init(hex: UInt32, alpha: Double = 1.0) {
        let r = Double((hex & 0xFF0000) >> 16) / 255.0
        let g = Double((hex & 0x00FF00) >>  8) / 255.0
        let b = Double(hex & 0x0000FF) / 255.0
        self = Color(.sRGB, red: r, green: g, blue: b, opacity: alpha)
    }
}
