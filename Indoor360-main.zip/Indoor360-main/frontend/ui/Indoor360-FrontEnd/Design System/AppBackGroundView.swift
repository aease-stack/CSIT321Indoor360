import SwiftUI

/// Branded app background used across screens.
/// Apply with: ⁠ .background(AppBackgroundView()) ⁠ on the root container.
struct AppBackgroundView: View {
    @Environment(\.colorScheme) private var scheme

    // Tunable tokens for the two-color blend
    private var lightColors: [Color] { [Color(hex: 0xFFFFFF), Color(hex: 0xF5F5F5)] }
    private var darkColors:  [Color] { [Color(hex: 0x0E0E0E), Color(hex: 0x141414)] }

    var body: some View {
        ZStack {
            // Two-color linear gradient (not animated; motion-safe)
            LinearGradient(
                colors: scheme == .dark ? darkColors : lightColors,
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            // Subtle PwC orange glow (brand tint), non-interactive
            RadialGradient(
                colors: [DSBrand.orange.opacity(scheme == .dark ? 0.16 : 0.10), .clear],
                center: .topLeading,
                startRadius: 2,
                endRadius: 280
            )
            .ignoresSafeArea()
            .allowsHitTesting(false)
            .accessibilityHidden(true)
        }
        // If you ever add transitions between themes, fall back to a simple fade for reduced motion:
        .transaction { txn in
            if UIAccessibility.isReduceMotionEnabled {
                txn.disablesAnimations = true
            }
        }
    }
}

#Preview  ("Light") {
    AppBackgroundView()
        .environment(\.colorScheme, .light)
}

#Preview ("Dark") {
    AppBackgroundView()
}

