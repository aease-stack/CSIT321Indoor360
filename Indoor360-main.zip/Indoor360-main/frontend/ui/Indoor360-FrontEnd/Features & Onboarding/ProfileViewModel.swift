import Foundation
import Combine

final class ProfileViewModel: ObservableObject {
    // User preferences, language, theme
}
