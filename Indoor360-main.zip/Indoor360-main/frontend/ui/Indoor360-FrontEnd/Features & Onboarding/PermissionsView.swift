import SwiftUI
import AVFoundation
import CoreLocation
import UserNotifications

struct PermissionsView: View {
    @EnvironmentObject private var appState: AppState
    @State private var permissionService = PermissionServiceImpl()
    
    @State private var cameraStatus: PermissionStatus   = .notDetermined
    @State private var locationStatus: PermissionStatus = .notDetermined
    @State private var notifStatus: PermissionStatus    = .notDetermined
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: Space.lg) {
                Text("Permissions")
                    .font(Typography.headlineL)
                    .foregroundColor(DSColor.textPrimary)
                    .padding(.horizontal, Space.lg)
                    .padding(.top, Space.lg)
                
                permCard(
                    title: "Camera",
                    copy: "We use the camera to place AR arrows and labels in your space.",
                    status: cameraStatus,
                    allowAction: requestCamera
                )
                
                permCard(
                    title: "Location",
                    copy: "We use your location to position you indoors and calculate routes.",
                    status: locationStatus,
                    allowAction: requestLocation
                )
                
                permCard(
                    title: "Notifications",
                    copy: "Get helpful updates like route changes or reminders. (Optional)",
                    status: notifStatus,
                    allowAction: requestNotifications
                )
                
                PrimaryButton(title: "Continue without some permissions") {
                    SettingsStore.saveCorePermissionsDone(true)
                    appState.hasCompletedCorePermissions = true
                    Haptics.confirm()
                }
                .padding(.horizontal, Space.lg)
                .padding(.bottom, Space.xl)
            }
        }
        .background(AppBackgroundView().ignoresSafeArea())
        .onAppear { refreshStatuses() }
    }
    
    // MARK: - Cards
    
    @ViewBuilder
    private func permCard(title: String, copy: String, status: PermissionStatus, allowAction: @escaping () -> Void) -> some View {
        Card {
            VStack(alignment: .leading, spacing: Space.sm) {
                HStack {
                    Text(title)
                        .font(Typography.headlineM)
                        .foregroundColor(DSColor.textPrimary)
                    Spacer()
                    badge(for: status)
                }
                
                Text(copy)
                    .font(Typography.body)
                    .foregroundColor(DSColor.textSecondary)
                
                HStack(spacing: Space.md) {
                    PrimaryButton(title: "Allow \(title)", action: allowAction)
                    Button("Not now") { }
                        .font(Typography.bodyEmphasis)
                        .foregroundColor(DSColor.textSecondary)
                        .minTapTarget()
                }
            }
        }
        .padding(.horizontal, Space.lg)
    }
    
    private func badge(for status: PermissionStatus) -> some View {
        let text: String
        let color: Color
        switch status {
        case .granted:       text = "Allowed"; color = DSColor.success
        case .denied:        text = "Denied";  color = DSColor.danger
        case .restricted:    text = "Limited"; color = DSColor.warning
        case .notDetermined: text = "Not set"; color = DSColor.textSecondary
        }
        return Text(text)
            .font(Typography.captionEmphasis)
            .foregroundColor(.white)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(color)
            .clipShape(Capsule())
            .accessibilityLabel(Text("\(text)"))
    }
    
    // MARK: - Requests
    
    private func requestCamera() {
        permissionService.requestCamera { status in
            cameraStatus = status
            refreshStatuses()
        }
    }
    
    private func requestLocation() {
        permissionService.requestLocation { status in
            locationStatus = status
            refreshStatuses()
        }
    }
    
    private func refreshStatuses() {
        // camera/location are synchronous in your service
        cameraStatus   = permissionService.cameraStatus()
        locationStatus = permissionService.locationStatus()
        
        // notifications are async – update when the callback returns
        permissionService.notificationStatus { status in
            notifStatus = status
        }
    }
    
    private func requestNotifications() {
        permissionService.requestNotifications { status in
            notifStatus = status
            // optionally re-pull all to keep cards in sync
            refreshStatuses()
        }
    }
}
    #Preview {
        PermissionsView().environmentObject(AppState())
    }

