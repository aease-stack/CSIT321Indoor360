import SwiftUI

struct OnboardingView: View {
    @EnvironmentObject private var appState: AppState
    @State private var page = 0

    var body: some View {
        VStack(spacing: 0) {
            TabView(selection: $page) {
                OnbSlide(
                    icon: "magnifyingglass",
                    title: "Find your way indoors",
                    subtitle: "Search venues and points of interest with ease."
                )
                .tag(0)

                OnbSlide(
                    icon: "figure.roll.runningpace",
                    title: "Step-free routes",
                    subtitle: "Accessible paths with elevators and wide corridors."
                )
                .tag(1)

                OnbSlide(
                    icon: "arkit",
                    title: "AR guidance",
                    subtitle: "See arrows and instructions overlaid in your space."
                )
                .tag(2)
            }
            .tabViewStyle(.page)
            .indexViewStyle(.page(backgroundDisplayMode: .always))

            VStack(spacing: Space.md) {
                PrimaryButton(
                    title: page < 2 ? "Next" : "Continue",
                    action: {
                        if page < 2 {
                            withAnimation { page += 1 }
                        } else {
                            SettingsStore.saveOnboardingDone(true)
                            appState.hasCompletedOnboarding = true
                            Haptics.confirm()
                        }
                    }
                )
                .padding(.horizontal, Space.lg)

                Button("Skip") {
                    SettingsStore.saveOnboardingDone(true)
                    appState.hasCompletedOnboarding = true
                    Haptics.confirm()
                }
                .font(Typography.bodyEmphasis)
                .foregroundColor(DSColor.accent)
                .minTapTarget()
            }
            .padding(.vertical, Space.lg)
        }
        .background(AppBackgroundView().ignoresSafeArea())
        .navigationBarBackButtonHidden(true)
    }
}

private struct OnbSlide: View {
    let icon: String
    let title: String
    let subtitle: String

    var bodyView: some View {
        VStack(spacing: Space.lg) {
            Image(systemName: icon)
                .font(.system(size: 72, weight: .semibold))
                .foregroundColor(DSColor.accent)
                .padding(.bottom, Space.sm)

            Text(title)
                .font(Typography.headlineL)
                .foregroundColor(DSColor.textPrimary)

            Text(subtitle)
                .font(Typography.body)
                .foregroundColor(DSColor.textSecondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, Space.xl)
        }
    }

    var body: some View {
        VStack { bodyView }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(.top, Space.xl)
    }
}

#Preview {
    OnboardingView().environmentObject(AppState())
}
