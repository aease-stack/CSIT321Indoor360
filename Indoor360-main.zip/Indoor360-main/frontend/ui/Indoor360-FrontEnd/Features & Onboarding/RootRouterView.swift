import SwiftUI

/// Routes the user to the right first screen based on session flags.
/// Order: Onboarding -> Auth -> Core Permissions -> Home
struct RootRouterView: View {
    @EnvironmentObject private var appState: AppState

    var body: some View {
        Group {
            if !appState.hasCompletedOnboarding {
                OnboardingView()
            }
            else if !appState.isAuthenticated {
                AuthView()
            }
            else if !appState.hasCompletedCorePermissions {
                PermissionsView()
            }
            else {
                HomeView()
            }
        }
        .preferredColorScheme(appState.appTheme)
    }
}

#Preview {
    let s = AppState()
    s.hasCompletedOnboarding = false
    s.isAuthenticated = false
    s.hasCompletedCorePermissions = false
    return RootRouterView().environmentObject(s)
}
