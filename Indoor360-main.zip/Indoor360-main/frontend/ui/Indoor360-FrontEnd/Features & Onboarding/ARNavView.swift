import SwiftUI
import ARKit
import RealityKit

struct ARNavView: View {
    @StateObject private var vm = ARNavViewModel()

    var body: some View {
        VStack {
            Text("AR Navigation")
                .font(Typography.titleL)
            Spacer()
        }
        .padding()
    }
}
