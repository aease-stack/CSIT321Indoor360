import Foundation
import Combine

final class ARNavViewModel: ObservableObject {
    // Alignment status, turn-by-turn state
}
