import SwiftUI

struct RouteSheet: View {
    let poiName: String
    @Binding var isPresented: Bool

    @State private var filter: MapRouteFilter = .normal
    @State private var distanceText: String = "--"
    @State private var timeText: String = "--"
    @State private var steps: [MapRouteStep] = []

    private let routing = RoutingService()

    var body: some View {
        VStack(spacing: Space.md) {
            // Drag handle
            Capsule()
                .fill(.secondary.opacity(0.5))
                .frame(width: 40, height: 5)
                .padding(.top, Space.sm)
                .accessibilityHidden(true)

            // Header
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Route to \(poiName)")
                        .font(Typography.headlineM)
                        .foregroundColor(DSColor.textPrimary)
                    Text("\(distanceText) • \(timeText)")
                        .font(Typography.caption)
                        .foregroundColor(DSColor.textSecondary)
                }
                Spacer()
                Button {
                    isPresented = false
                } label: {
                    Image(systemName: "xmark")
                        .font(.body.weight(.semibold))
                        .foregroundColor(DSColor.textPrimary)
                        .frame(width: AX.minTapSize, height: AX.minTapSize)
                        .background(.ultraThinMaterial)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
                .accessibilityLabel(Text("Close route"))
            }
            .padding(.horizontal, Space.lg)

            // Filters
            HStack(spacing: Space.sm) {
                filterChip("Step-free", isOn: filter == .stepFree) { setFilter(.stepFree) }
                filterChip("Elevators only", isOn: filter == .elevatorsOnly) { setFilter(.elevatorsOnly) }
                filterChip("Quiet", isOn: filter == .quiet) { setFilter(.quiet) }
            }
            .padding(.horizontal, Space.lg)

            // Steps
            List {
                ForEach(steps) { step in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(step.instruction)
                            .font(Typography.bodyEmphasis)
                            .foregroundColor(DSColor.textPrimary)
                        Text("\(step.distanceMeters)m • \(secondsToMin(step.durationSeconds))")
                            .font(Typography.caption)
                            .foregroundColor(DSColor.textSecondary)
                    }
                    .padding(.vertical, 4)
                    .accessibilityLabel(Text("\(step.instruction), \(step.distanceMeters) meters, \(secondsToMin(step.durationSeconds))"))
                }
            }
            .listStyle(.plain)
            .frame(maxHeight: 260)

            // CTA row
            HStack {
                Spacer()
                Button {
                    Haptics.reroute()
                } label: {
                    Text("Start Navigation")
                        .font(Typography.bodyEmphasis)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(DSColor.accent)
                        .foregroundColor(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .shadow(color: .black.opacity(0.12), radius: 12, y: 4)
                }
                .minTapTarget()
            }
            .padding(.horizontal, Space.lg)
            .padding(.bottom, Space.lg)
        }
        .background(
            Group {
                if UIAccessibility.isReduceTransparencyEnabled {
                    DSColor.surface
                } else {
                    Color.clear.background(.ultraThinMaterial)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
            .shadow(color: .black.opacity(0.12), radius: 16, y: 6)
        )
        .onAppear { refreshRoute() }
        .onChange(of: filter) {    // ← iOS 17+ zero-param form
            refreshRoute()
        }
        .accessibilityElement(children: .contain)
    }

    private func setFilter(_ f: MapRouteFilter) {
        withOptionalMotion {
            filter = f
            Haptics.reroute()
        }
    }

    private func refreshRoute() {
        let out = routing.fetchRoute(to: poiName, filter: filter)
        steps = out.steps
        distanceText = "\(out.distanceMeters)m"
        timeText = secondsToMin(out.durationSeconds)
    }

    private func filterChip(_ title: String, isOn: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(Typography.captionEmphasis)
                .foregroundColor(isOn ? .white : DSColor.textPrimary)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(isOn ? DSColor.accent : DSColor.surface)
                .clipShape(Capsule())
                .shadow(color: .black.opacity(isOn ? 0.18 : 0.06), radius: isOn ? 12 : 6, y: 2)
        }
        .accessibilityLabel(Text("\(title) filter"))
        .minTapTarget()
        .buttonStyle(.plain)
    }

    private func secondsToMin(_ s: Int) -> String {
        let m = s / 60
        let rs = s % 60
        return m > 0 ? "\(m)m \(rs)s" : "\(rs)s"
    }

    private func withOptionalMotion(_ changes: @escaping () -> Void) {
        if UIAccessibility.isReduceMotionEnabled {
            changes()
        } else {
            withAnimation(.easeInOut(duration: 0.25), changes)
        }
    }
}
