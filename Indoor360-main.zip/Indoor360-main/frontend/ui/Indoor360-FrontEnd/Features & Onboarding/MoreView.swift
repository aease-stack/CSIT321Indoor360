import SwiftUI

struct MoreView: View {
    @EnvironmentObject private var appState: AppState
    @State private var showToast = false
    @State private var toastMessage = ""
    @State private var toastStyle: ToastStyle = .info

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                // Appearance (Light/Dark/System)
                AppearanceSection()
                    .environmentObject(appState)
                    .glassBackground(cornerRadius: 20)
                    .padding(.horizontal, Space.lg)
                    .padding(.top, Space.lg)

                // Help & FAQ (placeholder)
                Card {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Help & FAQ")
                            .font(Typography.bodyEmphasis)
                            .foregroundStyle(DSColor.textPrimary)
                        Text("Find answers to common questions and tips for Indoor360.")
                            .font(Typography.body)
                            .foregroundStyle(DSColor.textSecondary)
                        PrimaryButton(title: "Open Help", action: {
                            toast(.info, "Help & FAQ (coming soon)")
                        })
                    }
                }
                .padding(.horizontal, Space.lg)

                // Report & Feedback (placeholder)
                Card {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Report & Feedback")
                            .font(Typography.bodyEmphasis)
                            .foregroundStyle(DSColor.textPrimary)
                        Text("Tell us if something isn’t working or share ideas to improve.")
                            .font(Typography.body)
                            .foregroundStyle(DSColor.textSecondary)
                        PrimaryButton(title: "Send Feedback", action: {
                            toast(.info, "Feedback form (coming soon)")
                        })
                    }
                }
                .padding(.horizontal, Space.lg)

                // About (placeholder)
                Card {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("About Indoor360")
                            .font(Typography.bodyEmphasis)
                            .foregroundStyle(DSColor.textPrimary)
                        Text("Version \(appVersion) (\(buildNumber))")
                            .font(Typography.caption)
                            .foregroundStyle(DSColor.textSecondary)
                        Text("Indoor wayfinding with accessible, step-free routing and AR guidance.")
                            .font(Typography.body)
                            .foregroundStyle(DSColor.textSecondary)
                    }
                }
                .padding(.horizontal, Space.lg)

                // Logout (temporary)
                Card {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Account")
                            .font(Typography.bodyEmphasis)
                            .foregroundStyle(DSColor.textPrimary)
                        PrimaryButton(title: "Log Out", action: {
                            Haptics.reroute()
                            appState.isAuthenticated = false
                            appState.isGuest = false
                            SettingsStore.clearSessionFlags()
                            toast(.info, "You’ve been logged out.")
                        })
                    }
                }
                .padding(.horizontal, Space.lg)

                Spacer(minLength: Space.xl)
            }
        }
        .background(AppBackgroundView())
        .navigationTitle("More")
        .navigationBarTitleDisplayMode(.inline)
        .toast(isPresented: $showToast, style: toastStyle, message: toastMessage, duration: 1.8)
    }

    // MARK: - Helpers
    private var appVersion: String {
        Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
    }
    private var buildNumber: String {
        Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"
    }
    private func toast(_ style: ToastStyle, _ message: String) {
        toastStyle = style
        toastMessage = message
        withAnimation { showToast = true }
    }
}

#Preview("More") {
    NavigationStack { MoreView().environmentObject(AppState()) }
        .background(AppBackgroundView())
}
