import SwiftUI

struct AdminView: View {
    @StateObject private var vm = AdminViewModel()
    var body: some View {
        VStack {
            Text("Admin")
                .font(Typography.titleL)
            Spacer()
        }
        .padding()
    }
}
