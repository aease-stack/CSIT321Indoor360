import Foundation
import Combine

final class AdminViewModel: ObservableObject {
    // Manage venues/POIs/anchors later
}
