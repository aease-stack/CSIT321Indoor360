import Foundation

final class PermissionsViewModel: ObservableObject {
    private let service: PermissionService

    @Published var camera: PermissionStatus = .notDetermined
    @Published var location: PermissionStatus = .notDetermined
    @Published var notifications: PermissionStatus = .notDetermined

    init(service: PermissionService = PermissionServiceImpl()) {
        self.service = service
        refresh()
    }

    func refresh() {
        camera = service.cameraStatus()
        location = service.locationStatus()
        service.notificationStatus { [weak self] status in
            self?.notifications = status
        }
    }

    func allowCamera() {
        service.requestCamera { [weak self] status in
            self?.camera = status
        }
    }

    func allowLocation() {
        service.requestLocation { [weak self] status in
            self?.location = status
        }
    }

    func allowNotifications() {
        service.requestNotifications { [weak self] status in
            self?.notifications = status
        }
    }

    func openSettings() {
        service.openAppSettings()
    }

    var missingCritical: Bool {
        // Camera & Location are important for AR navigation.
        !(camera == .granted && location == .granted)
    }
}
