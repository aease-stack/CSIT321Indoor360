import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var appState: AppState

    @State private var showToast = false
    @State private var toastMessage = ""
    @State private var toastStyle: ToastStyle = .info

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: Space.lg) {

                    topBar

                    // Search hero
                    NavigationLink {
                        SearchView()
                    } label: {
                        HStack(spacing: Space.sm) {
                            Image(systemName: "magnifyingglass")
                                .foregroundColor(DSColor.textSecondary)
                            Text("Search for places, toilets, elevators…")
                                .font(Typography.body)
                                .foregroundColor(DSColor.textSecondary)
                                .lineLimit(1)
                            Spacer()
                        }
                        .padding(.horizontal, Space.md)
                        .frame(height: 52)
                        .background(Color(UIColor.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                    .padding(.horizontal, Space.lg)
                    .accessibilityLabel("Search")

                    // Carousel / hero card (placeholder)
                    Card {
                        VStack(alignment: .leading, spacing: Space.sm) {
                            Text("Welcome to Indoor360")
                                .font(Typography.headlineM)
                                .foregroundStyle(DSColor.textPrimary)
                            Text("Find accessible routes and explore venues.")
                                .font(Typography.caption)
                                .foregroundStyle(DSColor.textSecondary)
                            Skeleton(cornerRadius: 14, height: 120)
                        }
                    }
                    .padding(.horizontal, Space.lg)

                    // Quick actions
                    SectionHeader(title: "Quick Actions")
                        .padding(.horizontal, Space.lg)

                    HStack(spacing: Space.md) {
                        // Start Navigation → VenueMapView
                        NavigationLink {
                            VenueMapView()
                        } label: {
                            quickActionContent(title: "Start Navigation", icon: "location.circle.fill")
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Start Navigation")

                        // Popular (mock)
                        Button {
                            toast(.info, "Popular places (coming soon)")
                        } label: {
                            quickActionContent(title: "Popular", icon: "star.fill")
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Popular places")

                        // Favorites (guest restricted)
                        Button {
                            if appState.isGuest {
                                toast(.info, "Sign in to save Favorites.")
                            } else {
                                toast(.info, "Favorites (coming soon)")
                            }
                        } label: {
                            quickActionContent(title: "Favorites", icon: "heart.fill")
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(appState.isGuest ? "Favorites (sign in required)" : "Favorites")

                        // Events (mock)
                        Button {
                            toast(.info, "Events (coming soon)")
                        } label: {
                            quickActionContent(title: "Events", icon: "calendar")
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Events")
                    }
                    .padding(.horizontal, Space.lg)

                    // Special offers (mock cards)
                    SectionHeader(title: "Special Offers", actionTitle: "View All", onAction: {
                        toast(.info, "View all offers (coming soon)")
                    })
                    .padding(.horizontal, Space.lg)
                    .padding(.top, -Space.sm)

                    VStack(spacing: Space.md) {
                        offerCard(title: "20% off at Café Al Noor", subtitle: "Level 2 • Today only")
                        offerCard(title: "Free gift at Dubai Souk Gifts", subtitle: "Level 1 • Until Friday")
                    }
                    .padding(.horizontal, Space.lg)

                    Spacer(minLength: Space.xl)
                }
            }
            .background(AppBackgroundView())
            .navigationBarTitleDisplayMode(.inline)
        }
        .toast(isPresented: $showToast, style: toastStyle, message: toastMessage, duration: 2.0)
    }

    // MARK: - Top Bar

    private var topBar: some View {
        HStack {
            // Profile placeholder
            NavigationLink {
                ProfileViewPlaceholder()
            } label: {
                Image(systemName: "person.crop.circle")
                    .font(.title2)
                    .foregroundColor(DSColor.textPrimary)
                    .frame(width: AX.minTapSize, height: AX.minTapSize)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Profile")

            Spacer()

            // Logo / Title
            Text("Indoor360")
                .font(Typography.headlineM)
                .foregroundStyle(DSColor.textPrimary)
                .accessibilityAddTraits(.isHeader)

            Spacer()

            // QR Scan shortcut
            NavigationLink {
                QRScanView()
            } label: {
                Image(systemName: "qrcode.viewfinder")
                    .font(.title2)
                    .foregroundColor(DSColor.accent)
                    .frame(width: AX.minTapSize, height: AX.minTapSize)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Scan QR")

            // Settings / More
            NavigationLink {
                MoreView()
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.title2)
                    .foregroundColor(DSColor.textPrimary)
                    .frame(width: AX.minTapSize, height: AX.minTapSize)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Settings")
        }
        .padding(.horizontal, Space.lg)
        .padding(.top, Space.md)
    }

    // MARK: - Subviews

    private func quickActionContent(title: String, icon: String) -> some View {
        VStack(spacing: Space.xs) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(DSColor.accent)
                .frame(height: 24)
            Text(title)
                .font(Typography.caption)
                .foregroundStyle(DSColor.textPrimary)
                .multilineTextAlignment(.center)
                .minimumScaleFactor(0.9)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, Space.md)
        .background(Color(UIColor.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .shadow(color: Color.black.opacity(0.06), radius: 6, y: 2)
        .minTapTarget()
    }

    private func offerCard(title: String, subtitle: String) -> some View {
        Card {
            VStack(alignment: .leading, spacing: Space.xs) {
                Text(title)
                    .font(Typography.bodyEmphasis)
                    .foregroundStyle(DSColor.textPrimary)
                Text(subtitle)
                    .font(Typography.caption)
                    .foregroundStyle(DSColor.textSecondary)
            }
        }
    }

    private func toast(_ style: ToastStyle, _ message: String) {
        toastStyle = style
        toastMessage = message
        withAnimation { showToast = true }
    }
}

// MARK: - Placeholder Profile View (safe stub)
private struct ProfileViewPlaceholder: View {
    var body: some View {
        VStack(spacing: 12) {
            Text("Profile")
                .font(Typography.headlineM)
                .foregroundStyle(DSColor.textPrimary)
            Text("Profile editing coming soon.")
                .font(Typography.body)
                .foregroundStyle(DSColor.textSecondary)
        }
        .padding()
        .background(AppBackgroundView())
        .navigationTitle("Profile")
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview("Home") {
    NavigationStack {
        HomeView()
            .environmentObject(AppState())
    }
}
