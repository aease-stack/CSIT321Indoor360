import Foundation
import Combine

final class AuthViewModel: ObservableObject {
    enum Mode { case signIn, signUp }
    enum AuthMethod { case password, otp }

    @Published var mode: Mode = .signIn
    @Published var method: AuthMethod = .password

    // Inputs
    @Published var fullName: String = ""
    @Published var email: String = ""
    @Published var password: String = ""
    @Published var phoneNumber: String = ""   // displayed string, e.g. "5X XXX XXXX"

    // UI
    @Published var isLoading = false
    @Published var errorMessage: String? = nil
    @Published var showOTPVerify = false

    // Helpers
    var phoneDigits: String { phoneNumber.filter(\.isNumber) }

    // Validation
    var isFullNameValid: Bool { fullName.trimmingCharacters(in: .whitespaces).count >= 2 }
    var isEmailValid: Bool { email.contains("@") && email.contains(".") && email.count >= 5 }
    var isPasswordValid: Bool { password.count >= 8 }
    var isPhoneValid: Bool {
        // Local UAE mobile: exactly 9 digits, starts with 5 (e.g., 5XXXXXXXX)
        let d = phoneDigits
        return d.count == 9 && d.first == "5"
    }

    var canSubmit: Bool {
        switch method {
        case .password:
            switch mode {
            case .signIn:
                return isEmailValid && isPasswordValid && !isLoading
            case .signUp:
                return isFullNameValid && isEmailValid && isPasswordValid && !isLoading
            }
        case .otp:
            return isPhoneValid && !isLoading
        }
    }

    func toggleMode() {
        mode = (mode == .signIn ? .signUp : .signIn)
        errorMessage = nil
    }

    func chooseOTP() {
        method = .otp
        errorMessage = nil
        // optional: clear email/password when switching to phone OTP
        // email = ""; password = ""
    }

    func choosePassword() {
        method = .password
        errorMessage = nil
    }

    // Primary action
    func primaryAction(completion: @escaping (Bool) -> Void) {
        guard canSubmit else {
            errorMessage = "Please fix the highlighted fields."
            completion(false)
            return
        }
        isLoading = true
        errorMessage = nil

        switch method {
        case .password:
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                self.isLoading = false
                completion(true)
            }
        case .otp:
            // Simulate sending OTP, then show Verify screen
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                self.isLoading = false
                self.showOTPVerify = true
                completion(true)
            }
        }
    }

    func forgotPassword() { }
    func continueWithGoogle() { errorMessage = nil }
    func continueWithFacebook() { errorMessage = nil }
}
