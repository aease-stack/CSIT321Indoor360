import SwiftUI

struct AuthView: View {
    @EnvironmentObject private var appState: AppState
    @StateObject private var vm = AuthViewModel()

    @State private var showToast = false
    @State private var toastMessage = ""
    @State private var toastStyle: ToastStyle = .info

    private var titleText: String {
        switch vm.method {
        case .password: return vm.mode == .signIn ? "Sign in" : "Create account"
        case .otp:      return "Sign in with phone"
        }
    }
    private var helperText: String {
        switch vm.method {
        case .password:
            return vm.mode == .signIn
                ? "Welcome back. Sign in to continue."
                : "Sign up to save favorites and history."
        case .otp:
            return "Enter your mobile number to receive a 6-digit code."
        }
    }
    private var primaryCTAText: String {
        switch vm.method {
        case .password: return vm.mode == .signIn ? "Continue" : "Create account"
        case .otp:      return "Send code"
        }
    }
    private var toggleText: AttributedString {
        AttributedString(vm.mode == .signIn
                         ? "Don’t have an account? Sign up"
                         : "Already have an account? Sign in")
    }

    var body: some View {
        ScrollView {
            VStack(spacing: Space.lg) {
                // Headings
                VStack(alignment: .leading, spacing: Space.xs) {
                    Text(titleText).font(Typography.headlineL).foregroundColor(DSColor.textPrimary)
                    Text(helperText).font(Typography.body).foregroundColor(DSColor.textSecondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, Space.lg)
                .padding(.top, Space.xl)

                // Inputs by method
                if vm.method == .password {
                    if vm.mode == .signUp {
                        TextFieldRow(
                            title: "Full name",
                            placeholder: "e.g., Sara Al Ali",
                            text: $vm.fullName,
                            helper: vm.isFullNameValid ? " " : "Please enter your full name.",
                            error: vm.isFullNameValid ? nil : (vm.fullName.isEmpty ? nil : "Name looks too short.")
                        )
                    }
                    TextFieldRow(
                        title: "Email address",
                        placeholder: "name@example.com",
                        text: $vm.email,
                        helper: vm.isEmailValid ? " " : "Enter a valid email (example@domain.com).",
                        error: vm.isEmailValid ? nil : (vm.email.isEmpty ? nil : "Invalid email format."),
                        keyboard: .emailAddress,
                        contentType: .emailAddress
                    )
                    PasswordField(
                        title: "Password",
                        placeholder: "At least 8 characters",
                        text: $vm.password,
                        helper: vm.isPasswordValid ? " " : "Use 8+ characters for strong security.",
                        error: vm.isPasswordValid ? nil : (vm.password.isEmpty ? nil : "Password too short.")
                    )

                    Button("Forgot password?") {
                        vm.forgotPassword()
                        showToast(.info, "Password reset link has been (mock) sent.")
                    }
                    .font(Typography.bodyEmphasis)
                    .foregroundColor(DSColor.accent)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    .padding(.horizontal, Space.lg)

                } else {
                    // PHONE OTP
                    TextFieldRow(
                        title: "Mobile number",
                        placeholder: "5X XXX XXXX",
                        text: $vm.phoneNumber,
                        helper: vm.isPhoneValid ? " " : "Local mobile format: 5X XXX XXXX",
                        error: vm.isPhoneValid ? nil : (vm.phoneNumber.isEmpty ? nil : "Number looks too short."),
                        keyboard: .phonePad,
                        contentType: .telephoneNumber
                    )
                    // Live format to "5X XXX XXXX"
                    .onChange(of: vm.phoneNumber) {
                        vm.phoneNumber = formatUAELocal(vm.phoneNumber)
                    }

                    Button("Use email & password instead") {
                        vm.choosePassword()
                    }
                    .font(Typography.body)
                    .foregroundColor(DSColor.textSecondary)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    .padding(.horizontal, Space.lg)
                }

                // Primary CTA
                PrimaryButton(
                    title: primaryCTAText,
                    action: {
                        vm.primaryAction { success in
                            if success {
                                if vm.method == .password {
                                    Haptics.confirm()
                                    appState.isGuest = false
                                    appState.isAuthenticated = true
                                    SettingsStore.saveIsGuest(false)
                                    SettingsStore.saveIsAuthenticated(true)
                                } else {
                                    // OTP path: we just navigated to Verify via showOTPVerify
                                    Haptics.light()
                                }
                            } else {
                                Haptics.critical()
                                showToast(.error, vm.errorMessage ?? "Check your details and try again.")
                            }
                        }
                    },
                    isLoading: vm.isLoading,
                    isDisabled: !vm.canSubmit
                )
                .padding(.horizontal, Space.lg)

                // Social / OTP chooser / Guest / Toggle
                VStack(spacing: Space.sm) {
                    Text("or")
                        .font(Typography.caption)
                        .foregroundColor(DSColor.textSecondary)

                    HStack(spacing: Space.md) {
                        socialButton(title: "Google", system: "g.circle")
                            .onTapGesture { vm.continueWithGoogle(); showToast(.info, "Google sign-in is a stub here.") }
                        socialButton(title: "Facebook", system: "f.cursive.circle")
                            .onTapGesture { vm.continueWithFacebook(); showToast(.info, "Facebook sign-in is a stub here.") }
                        socialButton(title: "OTP", system: "number.square")
                            .onTapGesture { vm.chooseOTP() } // switch to phone input
                    }
                    .padding(.horizontal, Space.lg)

                    Button("Continue as Guest") {
                        appState.isGuest = true
                        appState.isAuthenticated = true
                        SettingsStore.saveIsGuest(true)
                        SettingsStore.saveIsAuthenticated(true)
                        Haptics.confirm()
                    }
                    .font(Typography.bodyEmphasis)
                    .foregroundColor(DSColor.accent)
                    .minTapTarget()

                    if vm.method == .password {
                        Button { vm.toggleMode() } label: {
                            Text(toggleText)
                                .font(Typography.body)
                                .foregroundColor(DSColor.textSecondary)
                        }
                        .padding(.bottom, Space.xl)
                    } else {
                        Spacer(minLength: Space.xl)
                    }
                }
            }
        }
        .background(AppBackgroundView().ignoresSafeArea())
        .navigationDestination(isPresented: $vm.showOTPVerify) {
            OTPVerifyView(phone: vm.phoneNumber)   // pass the formatted local number
        }
        .toast(isPresented: $showToast, style: toastStyle, message: toastMessage, duration: 2.0)
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Helpers

    private func showToast(_ style: ToastStyle, _ message: String) {
        toastStyle = style
        toastMessage = message
        withAnimation { showToast = true }
    }

    // Format local UAE mobile as "5X XXX XXXX"
    private func formatUAELocal(_ raw: String) -> String {
        let digits = raw.filter(\.isNumber)
        // Limit to 9 digits, e.g., 5XXXXXXXX
        let clipped = String(digits.prefix(9))
        var out = ""
        for (i, ch) in clipped.enumerated() {
            if i == 0 { out.append(ch) }                 // 5
            else if i == 1 { out.append(" \(ch)") }      // "5X"
            else if i == 4 { out.append(" \(ch)") }      // "5X XXX"
            else { out.append(ch) }                      // rest
        }
        return out
    }

    @ViewBuilder
    private func socialButton(title: String, system: String) -> some View {
        HStack(spacing: Space.sm) {
            Image(systemName: system).font(.title3.weight(.semibold))
            Text("Continue with \(title)").font(Typography.bodyEmphasis)
        }
        .frame(maxWidth: .infinity, minHeight: 48, alignment: .center)
        .background(DSColor.surface)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .shadow(color: Color.black.opacity(0.05), radius: 6, y: 2)
        .accessibilityLabel(Text("Continue with \(title)"))
    }
}

#Preview {
    NavigationStack { AuthView().environmentObject(AppState()) }
}
