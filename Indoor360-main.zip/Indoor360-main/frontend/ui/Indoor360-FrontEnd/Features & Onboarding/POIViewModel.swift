import Foundation
import Combine

final class POIViewModel: ObservableObject {
    // Details for a specific POI
}
