import SwiftUI

struct POIView: View {
    @StateObject private var vm = POIViewModel()
    var body: some View {
        VStack {
            Text("POI Details")
                .font(Typography.titleL)
            Spacer()
        }
        .padding()
    }
}
