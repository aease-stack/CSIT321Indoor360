import SwiftUI

struct SearchView: View {
    @EnvironmentObject private var appState: AppState
    @StateObject private var vm = SearchViewModel()

    @State private var showToast = false
    @State private var toastMessage = ""
    @State private var toastStyle: ToastStyle = .info

    var body: some View {
        VStack(spacing: Space.md) {

            // Search field
            HStack(spacing: Space.sm) {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(DSColor.textSecondary)

                TextField("Search for shops, toilets, elevators…", text: $vm.query)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .foregroundColor(DSColor.textPrimary)
                    .tint(DSColor.accent)

                Button(action: { /* voice (stub) */ toast(.info, "Voice search is a stub.") }) {
                    Image(systemName: "mic.fill")
                        .foregroundColor(DSColor.accent)
                        .frame(width: AX.minTapSize, height: AX.minTapSize)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(Text("Voice search"))
            }
            .padding(.horizontal, Space.md)
            .frame(height: 52)
            .background(DSColor.surface)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .padding(.horizontal, Space.lg)
            .padding(.top, Space.md)

            // Content
            if vm.isSearching {
                VStack(spacing: Space.sm) {
                    Skeleton()
                    Skeleton()
                    Skeleton()
                }
                .padding(.horizontal, Space.lg)
            } else if vm.query.isEmpty {
                // Recents
                recentList
            } else if vm.results.isEmpty {
                emptyState
            } else {
                resultsList
            }

            Spacer(minLength: Space.md)
        }
        .toast(isPresented: $showToast, style: toastStyle, message: toastMessage, duration: 2.0)
        .background(AppBackgroundView())
        .navigationTitle("Search")
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Subviews

    private var recentList: some View {
        VStack(alignment: .leading, spacing: Space.sm) {
            HStack {
                Text("Recents")
                    .font(Typography.headlineM)
                Spacer()
                Button("Clear") { vm.clearRecents() }
                    .font(Typography.captionEmphasis)
                    .foregroundColor(DSColor.accent)
                    .minTapTarget()
            }
            .padding(.horizontal, Space.lg)

            if vm.recents.isEmpty {
                Text("No recent searches yet.")
                    .font(Typography.caption)
                    .foregroundColor(DSColor.textSecondary)
                    .padding(.horizontal, Space.lg)
            } else {
                ForEach(vm.recents, id: \.self) { term in
                    Button(action: { vm.tapRecent(term) }) {
                        HStack {
                            Image(systemName: "clock")
                                .foregroundColor(DSColor.textSecondary)
                            Text(term)
                                .foregroundColor(DSColor.textPrimary)
                            Spacer()
                        }
                        .padding(.vertical, Space.xs)
                        .padding(.horizontal, Space.lg)
                    }
                    .buttonStyle(.plain)
                    .minTapTarget()
                }
            }
        }
    }

    private var resultsList: some View {
        List {
            ForEach(vm.results) { poi in
                Button {
                    vm.selectResult(poi)
                    toast(.info, "Open \(poi.name) (mock)")
                } label: {
                    HStack(spacing: Space.md) {
                        Image(systemName: icon(for: poi.category))
                            .foregroundColor(DSColor.accent)
                            .frame(width: 28)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(poi.name)
                                .font(Typography.bodyEmphasis)
                                .foregroundColor(DSColor.textPrimary)
                            Text("\(poi.category.rawValue.capitalized) • floor \(poi.floor)\(poi.distanceMeters != nil ? " • \(poi.distanceMeters!)m" : "")")
                                .font(Typography.caption)
                                .foregroundColor(DSColor.textSecondary)
                        }
                        Spacer()
                    }
                    .contentShape(Rectangle())
                }
                .accessibilityLabel(Text("\(poi.name), \(poi.category.rawValue) on floor \(poi.floor)"))
            }
        }
        .listStyle(.plain)
    }

    private var emptyState: some View {
        VStack(spacing: Space.sm) {
            Image(systemName: "magnifyingglass.circle")
                .font(.system(size: 44))
                .foregroundColor(DSColor.textSecondary)
            Text("No results")
                .font(Typography.headlineM)
            Text("Try a different keyword, like “elevator” or “toilet”.")
                .font(Typography.caption)
                .foregroundColor(DSColor.textSecondary)
        }
        .padding(.top, Space.xl)
    }

    private func icon(for cat: POICategory) -> String {
        switch cat {
        case .shop: return "bag"
        case .restaurant: return "fork.knife"
        case .toilet: return "toilet.circle"
        case .elevator: return "arrow.up.and.down.circle"
        case .exit: return "door.left.hand.open"
        case .info: return "info.circle"
        case .atm: return "banknote"
        }
    }

    private func toast(_ style: ToastStyle, _ message: String) {
        toastStyle = style
        toastMessage = message
        withAnimation { showToast = true }
    }
}

#if DEBUG
struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack { SearchView().environmentObject(AppState()) }
    }
}
#endif
