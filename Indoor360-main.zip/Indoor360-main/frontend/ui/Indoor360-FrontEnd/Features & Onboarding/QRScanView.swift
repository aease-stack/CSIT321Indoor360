import SwiftUI
import AVFoundation

// MARK: - Camera preview host
struct CameraPreview: UIViewRepresentable {
    let scanner: QRCodeScanner
    func makeUIView(context: Context) -> QRPreviewView {
        let v = QRPreviewView()
        v.attach(layer: scanner.makePreviewLayer())
        return v
    }
    func updateUIView(_ uiView: QRPreviewView, context: Context) { }
}

// MARK: - QR Scanner Screen
struct QRScanView: View {
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.dismiss) private var dismiss

    @State private var scanner = QRCodeScanner()
    @State private var permissionService = PermissionServiceImpl()

    @State private var cameraStatus: PermissionStatus = .notDetermined
    @State private var torchOn = false
    @State private var torchAvailable = false
    @State private var isConfigured = false

    @State private var showToast = false
    @State private var toastMessage = ""
    @State private var toastStyle: ToastStyle = .info

    var body: some View {
        ZStack {
            // Camera when permitted, otherwise brand background
            if cameraStatus == .granted {
                CameraPreview(scanner: scanner)
                    .ignoresSafeArea()
            } else {
                AppBackgroundView()
                    .ignoresSafeArea()
            }

            // Framing box overlay
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.9), lineWidth: 2)
                .frame(width: 260, height: 260)
                .shadow(color: .black.opacity(0.35), radius: 8, y: 3)
                .accessibilityHidden(true)

            // Bottom helpers
            VStack {
                Spacer()
                if cameraStatus != .granted {
                    permissionCard
                        .padding(.horizontal, Space.lg)
                        .padding(.bottom, Space.xl)
                } else {
                    #if targetEnvironment(simulator)
                    Button {
                        Haptics.light()
                        scanner.pause()
                        handleScanResult("poi:CAFENOOR") // simulate
                    } label: {
                        Text("Simulate Scan")
                            .font(Typography.bodyEmphasis)
                            .foregroundColor(.white)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                            .background(Color.black.opacity(0.35))
                            .clipShape(Capsule())
                    }
                    .padding(.bottom, Space.xl)
                    #endif
                }
            }
        }
        .navigationTitle("Scan QR")
        .navigationBarTitleDisplayMode(.inline)
        // Use the system back button (no custom back so we avoid doubles)
        .toolbar {
            // Torch on trailing side when available
            ToolbarItem(placement: .navigationBarTrailing) {
                if torchAvailable && cameraStatus == .granted {
                    Button(action: toggleTorch) {
                        Image(systemName: torchOn ? "flashlight.on.fill" : "flashlight.off.fill")
                            .font(.title3.weight(.semibold))
                    }
                    .accessibilityLabel(Text(torchOn ? "Torch on" : "Torch off"))
                }
            }
        }
        .onAppear {
            refreshPermission()
            configureIfNeeded()
            attachHandler()
        }
        .onDisappear {
            scanner.stop()
            if scanner.isTorchOn { scanner.setTorch(enabled: false) }
        }
        // iOS 17+ signature
        .onChange(of: scenePhase) { _, newPhase in
            if newPhase == .active {
                refreshPermission()
                if cameraStatus == .granted {
                    configureIfNeeded()
                    scanner.start()
                }
            }
        }
        .toast(isPresented: $showToast, style: toastStyle, message: toastMessage, duration: 2.0)
        .accessibilityElement(children: .contain)
    }

    // MARK: - Permission card
    private var permissionCard: some View {
        Card {
            VStack(alignment: .leading, spacing: Space.sm) {
                Text("Enable Camera")
                    .font(Typography.headlineM)
                    .foregroundColor(DSColor.textPrimary)
                Text("We use the camera to scan QR codes and place AR guidance. You can enable it in Settings.")
                    .font(Typography.body)
                    .foregroundColor(DSColor.textSecondary)

                HStack(spacing: Space.sm) {
                    Button("Fix in Settings") {
                        permissionService.openAppSettings()
                    }
                    .font(Typography.bodyEmphasis)
                    .foregroundColor(DSColor.accent)
                    .minTapTarget()

                    Spacer()

                    Button("Try again") {
                        refreshPermission()
                        if cameraStatus == .granted {
                            configureIfNeeded()
                            scanner.start()
                            toast(.info, "Camera enabled.")
                        } else {
                            toast(.info, "Camera still denied. Use Fix in Settings.")
                        }
                    }
                    .font(Typography.bodyEmphasis)
                    .foregroundColor(DSColor.accent)
                    .minTapTarget()
                }
            }
        }
        .accessibilityLabel(Text("Camera permission is required to scan QR codes."))
    }

    // MARK: - Logic
    private func refreshPermission() {
        cameraStatus = permissionService.cameraStatus()
        if cameraStatus == .notDetermined {
            permissionService.requestCamera { status in
                cameraStatus = status
                if status == .granted {
                    configureIfNeeded()
                    scanner.start()
                }
            }
        } else if cameraStatus == .granted {
            scanner.start()
        }
    }

    private func configureIfNeeded() {
        guard !isConfigured else { return }
        scanner.configure { ok in
            isConfigured = ok
            torchAvailable = scanner.isTorchAvailable
            if ok { scanner.start() }
        }
    }

    private func attachHandler() {
        scanner.onCode = { raw in
            Haptics.light()
            handleScanResult(raw)
        }
    }

    private func handleScanResult(_ raw: String) {
        let link = DeepLinkRouter.parse(raw)
        let message = DeepLinkRouter.description(for: link)

        UIAccessibility.post(notification: .announcement, argument: message)
        toast(.info, message)

        // Debounce: pause briefly, then allow new scans
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.25) {
            scanner.resume()
        }
    }

    private func toggleTorch() {
        let newValue = !scanner.isTorchOn
        scanner.setTorch(enabled: newValue)
        torchOn = newValue
        Haptics.light()
    }

    private func toast(_ style: ToastStyle, _ message: String) {
        toastStyle = style
        toastMessage = message
        withAnimation { showToast = true }
    }
}
