import Foundation
import Combine

final class VenueMapViewModel: ObservableObject {
    // Floor selection, map state, selected POI
}
