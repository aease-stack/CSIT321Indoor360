import Foundation
import Combine

final class SearchViewModel: ObservableObject {
    @Published var query: String = ""
    @Published var results: [POI] = []
    @Published var recents: [String] = SearchHistoryStore.load()
    @Published var isSearching: Bool = false

    private let service: POIService
    private var bag = Set<AnyCancellable>()

    init(service: POIService = MockPOIService()) {
        self.service = service
        bind()
    }

    private func bind() {
        $query
            .removeDuplicates()
            .debounce(for: .milliseconds(250), scheduler: DispatchQueue.main)
            .sink { [weak self] q in
                guard let self else { return }
                if q.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    self.isSearching = false
                    self.results = []
                    return
                }
                self.isSearching = true
                self.service.searchPOIs(query: q)
                    .sink { [weak self] items in
                        self?.isSearching = false
                        self?.results = items
                    }
                    .store(in: &self.bag)
            }
            .store(in: &bag)
    }

    func selectResult(_ poi: POI) {
        SearchHistoryStore.add(query)
        recents = SearchHistoryStore.load()
        // Navigation to POI detail / route will come in later steps
    }

    func tapRecent(_ term: String) {
        query = term
    }

    func clearRecents() {
        SearchHistoryStore.clear()
        recents = []
    }
}
