import SwiftUI

struct VenueMapView: View {
    // Simple floor model
    private let floors = ["L1", "L2", "L3"]
    @State private var currentFloorIndex = 0

    // Map transform
    @State private var scale: CGFloat = 1.0
    @State private var offset: CGSize = .zero
    @State private var lastDrag: CGSize = .zero

    // POIs (mock)
    private struct Pin: Identifiable { let id = UUID(); let name: String; let point: CGPoint; let floor: String }
    private let pins: [Pin] = [
        .init(name: "Elevator A", point: CGPoint(x: 0.3, y: 0.4), floor: "L1"),
        .init(name: "Café Al Noor", point: CGPoint(x: 0.65, y: 0.5), floor: "L2"),
        .init(name: "Restroom North", point: CGPoint(x: 0.55, y: 0.2), floor: "L1"),
        .init(name: "Dubai Souk Gifts", point: CGPoint(x: 0.2, y: 0.75), floor: "L3"),
    ]

    // Selection / sheet
    @State private var selectedPOI: Pin? = nil
    @State private var showRouteSheet = false

    var body: some View {
        ZStack {
            // Placeholder "vector" map
            GeometryReader { geo in
                ZStack {
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .fill(LinearGradient(colors: [DSColor.surface, DSColor.background], startPoint: .top, endPoint: .bottom))
                        .overlay(
                            // simple grid
                            GridOverlay()
                                .opacity(0.15)
                                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                        )
                        .shadow(color: .black.opacity(0.08), radius: 16, y: 6)

                    // Pins for current floor
                    ForEach(pins.filter { $0.floor == currentFloor }) { pin in
                        let x = pin.point.x * geo.size.width
                        let y = pin.point.y * geo.size.height
                        Button {
                            selectedPOI = pin
                        } label: {
                            VStack(spacing: 4) {
                                Image(systemName: "mappin.circle.fill")
                                    .font(.title2)
                                    .foregroundColor(DSColor.accent)
                                Text(pin.name)
                                    .font(Typography.caption)
                                    .foregroundColor(DSColor.textPrimary)
                                    .fixedSize(horizontal: true, vertical: false)
                            }
                            .padding(6)
                            .background(.ultraThinMaterial)
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .shadow(color: .black.opacity(0.12), radius: 8, y: 3)
                        }
                        .position(x: x, y: y)
                        .accessibilityLabel(Text(pin.name))
                        .buttonStyle(.plain)
                    }
                }
                .scaleEffect(scale)
                .offset(offset)
                .gesture(panGesture())
                .gesture(pinchGesture())
                .animation(UIAccessibility.isReduceMotionEnabled ? nil : .easeInOut(duration: 0.2), value: scale)
                .animation(UIAccessibility.isReduceMotionEnabled ? nil : .easeInOut(duration: 0.2), value: offset)
                .padding(.horizontal, Space.lg)
                .padding(.top, Space.md)
            }

            // Floor selector
            VStack {
                HStack {
                    Spacer()
                    Picker("Floor", selection: $currentFloorIndex) {
                        ForEach(0..<floors.count, id: \.self) { i in
                            Text(floors[i]).tag(i)
                        }
                    }
                    .pickerStyle(.segmented)
                    .frame(width: 200)
                    .padding(.trailing, Space.lg)
                    .accessibilityLabel(Text("Floor"))
                }
                Spacer()
            }
        }
        .sheet(item: $selectedPOI) { sel in
            POISheet(poiName: sel.name, onStart: {
                Haptics.confirm()
                showRouteSheet = true
            })
            .presentationDetents([.medium])           // keep it simple; can add .large later
            .presentationBackground(.ultraThinMaterial)
            .presentationCornerRadius(24)
        }
        .sheet(isPresented: $showRouteSheet) {
            RouteSheet(poiName: selectedPOI?.name ?? "Destination", isPresented: $showRouteSheet)
                .presentationDetents([.medium, .large])
                .presentationBackground(.ultraThinMaterial)
                .presentationCornerRadius(24)
        }
        .navigationTitle("Venue Map")
        .navigationBarTitleDisplayMode(.inline)
        .background(AppBackgroundView())
    }

    private var currentFloor: String { floors[currentFloorIndex] }

    // MARK: Gestures
    private func panGesture() -> some Gesture {
        DragGesture()
            .onChanged { value in
                offset = CGSize(width: lastDrag.width + value.translation.width,
                                height: lastDrag.height + value.translation.height)
            }
            .onEnded { _ in
                lastDrag = offset
            }
    }

    private func pinchGesture() -> some Gesture {
        MagnificationGesture()
            .onChanged { value in
                scale = max(0.6, min(2.5, value))
            }
    }
}

// Small helper overlays/sheets used by the map

private struct GridOverlay: View {
    var body: some View {
        GeometryReader { geo in
            Path { p in
                let step: CGFloat = 32
                var x: CGFloat = 0
                while x < geo.size.width {
                    p.move(to: CGPoint(x: x, y: 0))
                    p.addLine(to: CGPoint(x: x, y: geo.size.height))
                    x += step
                }
                var y: CGFloat = 0
                while y < geo.size.height {
                    p.move(to: CGPoint(x: 0, y: y))
                    p.addLine(to: CGPoint(x: geo.size.width, y: y))
                    y += step
                }
            }
            .stroke(DSColor.textSecondary.opacity(0.15), lineWidth: 0.5)
        }
    }
}

private struct POISheet: View {
    let poiName: String
    let onStart: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: Space.md) {
            Capsule()
                .fill(.secondary.opacity(0.5))
                .frame(width: 40, height: 5)
                .padding(.top, Space.sm)
                .accessibilityHidden(true)

            Text(poiName)
                .font(Typography.headlineM)
                .foregroundColor(DSColor.textPrimary)

            Text("Accessible routes available. Includes step-free options.")
                .font(Typography.caption)
                .foregroundColor(DSColor.textSecondary)

            Spacer()

            Button(action: onStart) {
                Text("Start")
                    .font(Typography.bodyEmphasis)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(DSColor.accent)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .shadow(color: .black.opacity(0.12), radius: 12, y: 4)
            }
            .minTapTarget()
        }
        .padding(.horizontal, Space.lg)
        .padding(.bottom, Space.lg)
        .background(
            Group {
                if UIAccessibility.isReduceTransparencyEnabled {
                    DSColor.surface
                } else {
                    Color.clear.background(.ultraThinMaterial)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        )
    }
}
