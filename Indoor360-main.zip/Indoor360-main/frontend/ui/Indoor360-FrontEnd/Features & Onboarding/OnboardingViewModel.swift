import Foundation

final class OnboardingViewModel: ObservableObject {
    struct Slide: Identifiable, Equatable {
        let id = UUID()
        let title: String
        let subtitle: String
        let systemImage: String
    }

    @Published var slides: [Slide] = [
        .init(title: "Find your way indoors",
              subtitle: "Search venues and points of interest with ease.",
              systemImage: "magnifyingglass"),
        .init(title: "Step-free routes",
              subtitle: "Accessible paths with elevators and wide corridors.",
              systemImage: "figure.roll"),
        .init(title: "AR guidance",
              subtitle: "See arrows and instructions overlaid in your space.",
              systemImage: "arkit")
    ]

    @Published var index: Int = 0

    var isLast: Bool { index >= slides.count - 1 }
}
