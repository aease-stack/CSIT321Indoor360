import SwiftUI
import Combine

struct OTPVerifyView: View {
    let phone: String

    @Environment(\.dismiss) private var dismiss

    @State private var code: String = ""          // 0...6 digits
    @FocusState private var focused: Bool

    @State private var isVerifying = false
    @State private var canResend = false
    @State private var secondsLeft = 30
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        VStack(spacing: Space.lg) {
            VStack(alignment: .leading, spacing: Space.xs) {
                Text("Enter the 6-digit code")
                    .font(Typography.headlineM)
                    .foregroundColor(DSColor.textPrimary)
                Text("We sent a code to \(phone)")
                    .font(Typography.body)
                    .foregroundColor(DSColor.textSecondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, Space.lg)
            .padding(.top, Space.lg)

            // Boxes drawn from 'code'
            HStack(spacing: 12) {
                ForEach(0..<6, id: \.self) { idx in
                    ZStack {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(DSColor.surface)
                            .frame(width: 48, height: 56)
                            .shadow(color: Color.black.opacity(0.06), radius: 8, y: 2)

                        Text(character(at: idx))
                            .font(.system(size: 22, weight: .semibold, design: .monospaced))
                            .foregroundColor(DSColor.textPrimary)
                    }
                    .accessibilityLabel(Text("Digit \(idx + 1)"))
                }
            }
            .padding(.vertical, 6)
            .onTapGesture { focused = true }
            .padding(.horizontal, Space.lg)

            // Hidden field that actually receives input
            TextField("", text: Binding(
                get: { code },
                set: { new in
                    let filtered = new.filter { $0.isNumber }
                    code = String(filtered.prefix(6))
                    if code.count == 6 { verify() }
                })
            )
            .keyboardType(.numberPad)
            .textContentType(.oneTimeCode)
            .foregroundColor(.clear)
            .accentColor(.clear)
            .disableAutocorrection(true)
            .focused($focused)
            .frame(width: 0, height: 0)
            .opacity(0.01)
            .accessibilityHidden(true)

            // Resend
            Button(canResend ? "Resend code" : "Resend in \(secondsLeft)s") {
                guard canResend else { return }
                canResend = false
                secondsLeft = 30
                Haptics.confirm() // mock send
            }
            .disabled(!canResend)
            .font(Typography.bodyEmphasis)
            .foregroundColor(canResend ? DSColor.accent : DSColor.textSecondary)

            Spacer()

            PrimaryButton(
                title: isVerifying ? "Verifying…" : "Verify",
                action: verify,
                isLoading: isVerifying,
                isDisabled: code.count < 6 || isVerifying
            )
            .padding(.horizontal, Space.lg)
            .padding(.bottom, Space.lg)
        }
        .background(AppBackgroundView().ignoresSafeArea())
        .onAppear {
            focused = true
            canResend = false
            secondsLeft = 30
        }
        .onReceive(timer) { _ in
            guard !canResend else { return }
            secondsLeft = max(0, secondsLeft - 1)
            if secondsLeft == 0 { canResend = true }
        }
        .navigationTitle("Verify")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func character(at index: Int) -> String {
        guard index < code.count else { return "" }
        let i = code.index(code.startIndex, offsetBy: index)
        return String(code[i])
    }

    private func verify() {
        guard !isVerifying, code.count == 6 else { return }
        isVerifying = true
        Haptics.light()
        // Mock verification
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            isVerifying = false
            // Treat success as signed-in (guest=false)
            // If you want to auto-complete login after OTP:
            // (You can also lift this to a shared AppState flag.)
            dismiss()
        }
    }
}
