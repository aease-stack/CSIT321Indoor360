import Foundation
import Combine

final class HomeViewModel: ObservableObject {
    // Hook VenueService, POIService later
}
