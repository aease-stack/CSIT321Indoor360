import SwiftUI

/// Section for picking app appearance: System / Light / Dark
struct AppearanceSection: View {
    @EnvironmentObject private var appState: AppState
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Appearance")
                .font(.headline)
                .foregroundStyle(DSColor.textPrimary)
            
            Picker("Appearance", selection: Binding(
                get: { themeToTag(appState.appTheme) },
                set: { newTag in
                    let newTheme = tagToTheme(newTag)
                    appState.appTheme = newTheme
                    SettingsStore.saveTheme(newTheme)
                }
            )) {
                Text("System").tag(0)
                Text("Light").tag(1)
                Text("Dark").tag(2)
            }
            .pickerStyle(.segmented)
            .frame(maxWidth: 280)
            .accessibilityLabel("App appearance selection")
        }
        .padding(.vertical, 8)
    }
    
    // MARK: - Mapping helpers
    private func themeToTag(_ theme: ColorScheme?) -> Int {
        switch theme {
        case .none: return 0   // system default
        case .some(.light): return 1
        case .some(.dark): return 2
        @unknown default: return 0
        }
    }
    
    private func tagToTheme(_ tag: Int) -> ColorScheme? {
        switch tag {
        case 0: return nil
        case 1: return .light
        case 2: return .dark
        default: return nil
        }
    }
}

#Preview {
    AppearanceSection()
        .environmentObject(AppState())
        .padding()
        .background(AppBackgroundView())
}
