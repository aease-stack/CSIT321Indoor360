import SwiftUI

struct ProfileView: View {
    @StateObject private var vm = ProfileViewModel()
    var body: some View {
        VStack {
            Text("Profile & Settings")
                .font(Typography.titleL)
            Spacer()
        }
        .padding()
    }
}
