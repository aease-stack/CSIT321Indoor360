import SwiftUI

/// A reusable BottomSheet modifier for Indoor360 using SwiftUI's .sheet.
struct BottomSheet<SheetContent: View>: ViewModifier {
    @Binding var isPresented: Bool
    let detents: Set<PresentationDetent>
    let content: () -> SheetContent

    func body(content base: Content) -> some View {
        base
            .sheet(isPresented: $isPresented) {
                self.content()
                    .glassBackground(cornerRadius: 24)
                    .presentationDetents(detents)
                    .presentationDragIndicator(.visible)
                    .presentationCornerRadius(24)
            }
    }
}

extension View {
    func bottomSheet<SheetContent: View>(
        isPresented: Binding<Bool>,
        detents: Set<PresentationDetent> = [.medium, .large],
        @ViewBuilder content: @escaping () -> SheetContent
    ) -> some View {
        modifier(BottomSheet(isPresented: isPresented, detents: detents, content: content))
    }
}
