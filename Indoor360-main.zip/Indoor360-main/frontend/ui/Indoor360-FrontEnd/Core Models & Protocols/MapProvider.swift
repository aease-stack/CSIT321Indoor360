import Foundation
import CoreLocation

/// Abstraction for any map renderer (MapKit, Mapbox, custom).
protocol MapProvider {
    func setFloor(_ floorId: String)
    func setCamera(center: CLLocationCoordinate2D, zoom: Double)
    // add more as needed later
}
