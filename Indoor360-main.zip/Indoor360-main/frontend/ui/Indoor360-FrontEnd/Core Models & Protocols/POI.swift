import Foundation

enum POICategory: String, Codable, CaseIterable {
    case shop, restaurant, toilet, elevator, exit, info, atm
}

struct POI: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String
    var category: POICategory
    var floor: String
    var distanceMeters: Int?

    init(id: UUID = UUID(),
         name: String,
         category: POICategory,
         floor: String,
         distanceMeters: Int? = nil) {
        self.id = id
        self.name = name
        self.category = category
        self.floor = floor
        self.distanceMeters = distanceMeters
    }
}
