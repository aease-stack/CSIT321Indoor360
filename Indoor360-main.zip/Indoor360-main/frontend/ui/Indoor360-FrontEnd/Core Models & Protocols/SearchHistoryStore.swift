import Foundation

enum SearchHistoryStore {
    private static let key = "search_recents"
    private static let maxItems = 10

    static func load() -> [String] {
        (UserDefaults.standard.array(forKey: key) as? [String]) ?? []
    }

    static func add(_ term: String) {
        var list = load().filter { $0.caseInsensitiveCompare(term) != .orderedSame }
        list.insert(term, at: 0)
        if list.count > maxItems { list.removeLast(list.count - maxItems) }
        UserDefaults.standard.set(list, forKey: key)
    }

    static func clear() {
        UserDefaults.standard.removeObject(forKey: key)
    }
}
