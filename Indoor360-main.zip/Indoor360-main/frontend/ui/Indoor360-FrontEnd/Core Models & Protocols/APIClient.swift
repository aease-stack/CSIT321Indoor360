import Foundation
import Combine

protocol APIClient {
    func request<T: Decodable>(_ endpoint: URLRequest) -> AnyPublisher<T, Error>
}

final class MockAPIClient: APIClient {
    func request<T>(_ endpoint: URLRequest) -> AnyPublisher<T, Error> where T : Decodable {
        Fail(error: URLError(.badURL)).eraseToAnyPublisher()
    }
}
