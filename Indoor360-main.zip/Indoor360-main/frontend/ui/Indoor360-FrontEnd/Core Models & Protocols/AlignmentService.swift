import Foundation
import Combine

/// Protocol for AR alignment (relocalization, drift, anchors).
protocol AlignmentService {
    var isAligned: AnyPublisher<Bool, Never> { get }
    func startAlignment(for venueId: String)
    func stopAlignment()
}

/// Mock publisher that instantly "aligns".
final class MockAlignmentService: AlignmentService {
    private let subject = CurrentValueSubject<Bool, Never>(false)
    var isAligned: AnyPublisher<Bool, Never> { subject.eraseToAnyPublisher() }

    func startAlignment(for venueId: String) { subject.send(true) }
    func stopAlignment() { subject.send(false) }
}
