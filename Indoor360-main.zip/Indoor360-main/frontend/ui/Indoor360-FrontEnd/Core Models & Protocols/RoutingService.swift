import Foundation

// MARK: - Namespaced Models (unique names)

struct MapRouteStep: Identifiable, Equatable {
    let id = UUID()
    let instruction: String
    let distanceMeters: Int
    let durationSeconds: Int
}

enum MapRouteFilter: Equatable {
    case normal
    case stepFree
    case elevatorsOnly
    case quiet
}

struct MapRouteSummary: Equatable {
    let distanceMeters: Int
    let durationSeconds: Int
    let steps: [MapRouteStep]
}

// MARK: - Service (mock)

final class RoutingService {
    init() {}

    func fetchRoute(to poiId: String, from start: String? = nil, filter: MapRouteFilter) -> MapRouteSummary {
        switch filter {
        case .normal:
            let steps = [
                MapRouteStep(instruction: "Head straight for 50m", distanceMeters: 50, durationSeconds: 60),
                MapRouteStep(instruction: "Turn left at escalator", distanceMeters: 25, durationSeconds: 40),
                MapRouteStep(instruction: "Continue to \(poiId)", distanceMeters: 30, durationSeconds: 45),
            ]
            return summarize(steps)

        case .stepFree:
            let steps = [
                MapRouteStep(instruction: "Proceed to Elevator A", distanceMeters: 18, durationSeconds: 45),
                MapRouteStep(instruction: "Ride elevator to destination floor", distanceMeters: 0, durationSeconds: 60),
                MapRouteStep(instruction: "Follow corridor to \(poiId)", distanceMeters: 55, durationSeconds: 75),
            ]
            return summarize(steps)

        case .elevatorsOnly:
            let steps = [
                MapRouteStep(instruction: "Go to nearest elevator", distanceMeters: 12, durationSeconds: 30),
                MapRouteStep(instruction: "Ride to destination floor", distanceMeters: 0, durationSeconds: 60),
                MapRouteStep(instruction: "Walk to \(poiId)", distanceMeters: 28, durationSeconds: 50),
            ]
            return summarize(steps)

        case .quiet:
            let steps = [
                MapRouteStep(instruction: "Take quiet corridor (right)", distanceMeters: 35, durationSeconds: 65),
                MapRouteStep(instruction: "Avoid atrium; continue behind stores", distanceMeters: 60, durationSeconds: 95),
                MapRouteStep(instruction: "Arrive at \(poiId)", distanceMeters: 10, durationSeconds: 20),
            ]
            return summarize(steps)
        }
    }

    private func summarize(_ steps: [MapRouteStep]) -> MapRouteSummary {
        let totalDistance = steps.reduce(0) { $0 + $1.distanceMeters }
        let totalDuration = steps.reduce(0) { $0 + $1.durationSeconds }
        return MapRouteSummary(distanceMeters: totalDistance, durationSeconds: totalDuration, steps: steps)
    }
}
