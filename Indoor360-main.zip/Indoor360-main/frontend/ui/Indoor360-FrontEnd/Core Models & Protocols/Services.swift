import Foundation
import AVFoundation
import CoreLocation
import UserNotifications
import UIKit

/// High-level permission statuses used by the UI.
enum PermissionStatus: Equatable {
    case notDetermined
    case granted
    case denied       // user denied (can still change in Settings)
    case restricted   // parental or system restriction
}

protocol PermissionService {
    // Camera
    func cameraStatus() -> PermissionStatus
    func requestCamera(completion: @escaping (PermissionStatus) -> Void)

    // Location (When In Use)
    func locationStatus() -> PermissionStatus
    func requestLocation(completion: @escaping (PermissionStatus) -> Void)

    // Notifications
    func notificationStatus(completion: @escaping (PermissionStatus) -> Void)
    func requestNotifications(completion: @escaping (PermissionStatus) -> Void)

    // Open iOS Settings for this app
    func openAppSettings()
}

/// Default implementation that wraps AVFoundation, CoreLocation, and UserNotifications.
final class PermissionServiceImpl: NSObject, PermissionService {
    private var locationManager: CLLocationManager?
    private var locationCompletion: ((PermissionStatus) -> Void)?

    // MARK: - Camera
    func cameraStatus() -> PermissionStatus {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:          return .granted
        case .notDetermined:       return .notDetermined
        case .denied:              return .denied
        case .restricted:          return .restricted
        @unknown default:          return .denied
        }
    }

    func requestCamera(completion: @escaping (PermissionStatus) -> Void) {
        AVCaptureDevice.requestAccess(for: .video) { granted in
            DispatchQueue.main.async {
                completion(granted ? .granted : .denied)
            }
        }
    }

    // MARK: - Location (When In Use)
    // Replace your current locationStatus() with this:
    func locationStatus() -> PermissionStatus {
        // Use an instance (iOS 14+)
        let manager = CLLocationManager()
        let status = manager.authorizationStatus

        switch status {
        case .authorizedWhenInUse, .authorizedAlways: return .granted
        case .notDetermined:                           return .notDetermined
        case .denied:                                  return .denied
        case .restricted:                              return .restricted
        @unknown default:                              return .denied
        }
    }

    func requestLocation(completion: @escaping (PermissionStatus) -> Void) {
        locationCompletion = completion
        let manager = CLLocationManager()
        manager.delegate = self
        self.locationManager = manager
        manager.requestWhenInUseAuthorization()
    }

    // MARK: - Notifications
    func notificationStatus(completion: @escaping (PermissionStatus) -> Void) {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            let status: PermissionStatus
            switch settings.authorizationStatus {
            case .authorized, .provisional, .ephemeral: status = .granted
            case .notDetermined:                         status = .notDetermined
            case .denied:                                status = .denied
            @unknown default:                            status = .denied
            }
            DispatchQueue.main.async { completion(status) }
        }
    }

    func requestNotifications(completion: @escaping (PermissionStatus) -> Void) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, _ in
            DispatchQueue.main.async {
                completion(granted ? .granted : .denied)
            }
        }
    }

    // MARK: - Settings
    func openAppSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
}

extension PermissionServiceImpl: CLLocationManagerDelegate {
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        guard let completion = locationCompletion else { return }
        completion(locationStatus())
        // release once we get a callback
        locationCompletion = nil
        locationManager = nil
    }
}
