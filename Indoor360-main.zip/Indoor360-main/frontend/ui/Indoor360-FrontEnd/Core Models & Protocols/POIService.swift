import Foundation
import Combine

protocol POIService {
    func searchPOIs(query: String) -> AnyPublisher<[POI], Never>
    func popularPOIs() -> AnyPublisher<[POI], Never>
}

final class MockPOIService: POIService {
    private let all: [POI] = [
        POI(name: "Elevator A", category: .elevator, floor: "G", distanceMeters: 30),
        POI(name: "Restroom North", category: .toilet, floor: "G", distanceMeters: 45),
        POI(name: "Dubai Souk Gifts", category: .shop, floor: "L1", distanceMeters: 120),
        POI(name: "Café Al Noor", category: .restaurant, floor: "L2", distanceMeters: 200),
        POI(name: "ATM Emirates", category: .atm, floor: "G", distanceMeters: 50),
        POI(name: "Info Desk Central", category: .info, floor: "G", distanceMeters: 15),
        POI(name: "Exit Gate 3", category: .exit, floor: "G", distanceMeters: 90)
    ]

    func searchPOIs(query: String) -> AnyPublisher<[POI], Never> {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return Just([]).eraseToAnyPublisher() }
        let results = all.filter {
            $0.name.localizedCaseInsensitiveContains(q) ||
            $0.category.rawValue.localizedCaseInsensitiveContains(q)
        }
        return Just(results)
            .delay(for: .milliseconds(250), scheduler: DispatchQueue.main) // mock latency
            .eraseToAnyPublisher()
    }

    func popularPOIs() -> AnyPublisher<[POI], Never> {
        Just(Array(all.prefix(4)))
            .delay(for: .milliseconds(200), scheduler: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
}
