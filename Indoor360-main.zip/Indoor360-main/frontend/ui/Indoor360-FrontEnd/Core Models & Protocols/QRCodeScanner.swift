import Foundation
import AVFoundation
import UIKit

/// Thin wrapper around AVCaptureSession for QR codes.
/// Handles start/stop, torch, and debounced result delivery.
final class QRCodeScanner: NSObject, AVCaptureMetadataOutputObjectsDelegate {

    private let session = AVCaptureSession()
    private var videoInput: AVCaptureDeviceInput?
    private let metadataOutput = AVCaptureMetadataOutput()
    private let sessionQueue = DispatchQueue(label: "qr.session.queue")
    private var isConfigured = false
    private var isRunning = false

    /// When true, we ignore additional scans (until resume()).
    private var paused = false

    /// Called on main queue with the decoded string.
    var onCode: ((String) -> Void)?

    /// Configure the capture session (idempotent).
    func configure(completion: @escaping (Bool) -> Void) {
        guard !isConfigured else { completion(true); return }
        sessionQueue.async {
            self.session.beginConfiguration()
            self.session.sessionPreset = .high

            guard
                let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                let input = try? AVCaptureDeviceInput(device: device),
                self.session.canAddInput(input)
            else {
                self.session.commitConfiguration()
                DispatchQueue.main.async { completion(false) }
                return
            }
            self.videoInput = input
            self.session.addInput(input)

            guard self.session.canAddOutput(self.metadataOutput) else {
                self.session.commitConfiguration()
                DispatchQueue.main.async { completion(false) }
                return
            }
            self.session.addOutput(self.metadataOutput)
            self.metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            self.metadataOutput.metadataObjectTypes = [.qr]

            self.session.commitConfiguration()
            self.isConfigured = true
            DispatchQueue.main.async { completion(true) }
        }
    }

    func start() {
        sessionQueue.async {
            guard self.isConfigured, !self.isRunning else { return }
            self.paused = false
            self.session.startRunning()
            self.isRunning = true
        }
    }

    func stop() {
        sessionQueue.async {
            guard self.isRunning else { return }
            self.session.stopRunning()
            self.isRunning = false
        }
    }

    func pause() { paused = true }
    func resume() { paused = false }

    // Torch
    var isTorchAvailable: Bool {
        (videoInput?.device.hasTorch ?? false)
    }

    var isTorchOn: Bool {
        (videoInput?.device.isTorchActive ?? false)
    }

    func setTorch(enabled: Bool) {
        guard let device = videoInput?.device, device.hasTorch else { return }
        do {
            try device.lockForConfiguration()
            device.torchMode = enabled ? .on : .off
            device.unlockForConfiguration()
        } catch { /* ignore */ }
    }

    // MARK: - Delegate
    func metadataOutput(_ output: AVCaptureMetadataOutput,
                        didOutput metadataObjects: [AVMetadataObject],
                        from connection: AVCaptureConnection) {
        guard !paused else { return }
        for obj in metadataObjects {
            if let code = obj as? AVMetadataMachineReadableCodeObject,
               code.type == .qr,
               let value = code.stringValue, !value.isEmpty {
                paused = true
                onCode?(value)
                break
            }
        }
    }

    // Simulator helper
    #if targetEnvironment(simulator)
    func simulateScan(_ text: String) {
        onCode?(text)
    }
    #endif

    // Expose the session layer host view
    func makePreviewLayer() -> AVCaptureVideoPreviewLayer {
        let layer = AVCaptureVideoPreviewLayer(session: session)
        layer.videoGravity = .resizeAspectFill
        return layer
    }
}

/// A UIView that hosts the AVCaptureVideoPreviewLayer for SwiftUI.
final class QRPreviewView: UIView {
    private var previewLayer: AVCaptureVideoPreviewLayer?

    func attach(layer: AVCaptureVideoPreviewLayer) {
        self.previewLayer?.removeFromSuperlayer()
        self.previewLayer = layer
        self.layer.insertSublayer(layer, at: 0)
        setNeedsLayout()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        previewLayer?.frame = bounds
    }
}
