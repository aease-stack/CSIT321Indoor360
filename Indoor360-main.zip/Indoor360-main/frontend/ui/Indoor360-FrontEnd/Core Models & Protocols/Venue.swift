import Foundation

struct Venue: Identifiable, Hashable {
    let id: String
    var name: String
    var floors: [String]
    var address: String?
}
