import Foundation
import Combine

protocol VenueService {
    func listVenues() -> AnyPublisher<[Venue], Never>
}

final class MockVenueService: VenueService {
    func listVenues() -> AnyPublisher<[Venue], Never> {
        Just([Venue(id: "dubai-mall", name: "Dubai Mall", floors: ["LG","G","L1","L2","L3"], address: nil)])
            .eraseToAnyPublisher()
    }
}
