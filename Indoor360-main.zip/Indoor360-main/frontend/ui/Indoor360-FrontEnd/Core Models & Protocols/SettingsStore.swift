import Foundation
import SwiftUI   // for ColorScheme

/// Simple persistence for user settings (front-end only).
enum SettingsStore {
    // MARK: - Keys
    private static let onboardingKey   = "hasCompletedOnboarding"
    private static let corePermsKey    = "hasCompletedCorePermissions"
    private static let authKey         = "isAuthenticated"
    private static let guestKey        = "isGuest"
    private static let themeKey        = "app_theme" // "system" | "light" | "dark"

    // MARK: - Auth / Session
    static func saveIsAuthenticated(_ value: Bool) {
        UserDefaults.standard.set(value, forKey: authKey)
    }
    static func loadIsAuthenticated() -> Bool {
        UserDefaults.standard.bool(forKey: authKey)
    }

    static func saveIsGuest(_ value: Bool) {
        UserDefaults.standard.set(value, forKey: guestKey)
    }
    static func loadIsGuest() -> Bool {
        UserDefaults.standard.bool(forKey: guestKey)
    }

    // MARK: - Onboarding / Core Permissions
    static func saveOnboardingDone(_ value: Bool) {
        UserDefaults.standard.set(value, forKey: onboardingKey)
    }
    static func loadOnboardingDone() -> Bool {
        UserDefaults.standard.bool(forKey: onboardingKey)
    }

    static func saveCorePermissionsDone(_ value: Bool) {
        UserDefaults.standard.set(value, forKey: corePermsKey)
    }
    static func loadCorePermissionsDone() -> Bool {
        UserDefaults.standard.bool(forKey: corePermsKey)
    }

    // MARK: - Appearance (Light/Dark/System)
    /// Persist user-selected theme. Pass ⁠ nil ⁠ to follow system.
    static func saveTheme(_ theme: ColorScheme?) {
        let value: String
        switch theme {
        case .light?: value = "light"
        case .dark?:  value = "dark"
        default:      value = "system"
        }
        UserDefaults.standard.set(value, forKey: themeKey)
    }

    /// Load user-selected theme, or ⁠ nil ⁠ to follow system.
    static func loadTheme() -> ColorScheme? {
        let value = UserDefaults.standard.string(forKey: themeKey) ?? "system"
        switch value {
        case "light": return .light
        case "dark":  return .dark
        default:      return nil
        }
    }

    // MARK: - Convenience
    /// Clears auth flags (use on logout)
    static func clearSessionFlags() {
        saveIsAuthenticated(false)
        saveIsGuest(false)
    }

    /// Nukes all stored flags (use carefully in debug)
    static func resetAll() {
        let defaults = UserDefaults.standard
        [onboardingKey, corePermsKey, authKey, guestKey, themeKey].forEach { defaults.removeObject(forKey: $0) }
        defaults.synchronize()
    }
}
