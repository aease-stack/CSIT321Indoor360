import Foundation
import Combine

enum AuthMode {
    case signIn
    case signUp
}

protocol AuthService {
    func signIn(email: String, password: String) -> AnyPublisher<Bool, Error>
    func signUp(email: String, password: String) -> AnyPublisher<Bool, Error>
    func sendOTP(to email: String) -> AnyPublisher<Bool, Error>
    func verifyOTP(email: String, code: String) -> AnyPublisher<Bool, Error>
    func logout() -> AnyPublisher<Bool, Never>
}

enum AuthError: LocalizedError {
    case invalidCredentials
    case weakPassword
    case network
    case unknown

    var errorDescription: String? {
        switch self {
        case .invalidCredentials: return "Invalid email or password."
        case .weakPassword:       return "Password is too weak."
        case .network:            return "Network error. Try again."
        case .unknown:            return "Something went wrong."
        }
    }
}

/// Mock implementation for front-end flows
final class MockAuthService: AuthService {
    func signIn(email: String, password: String) -> AnyPublisher<Bool, Error> {
        // Simulate a delay and accept any non-empty password
        let ok = !email.isEmpty && !password.isEmpty
        return Just(ok)
            .delay(for: .milliseconds(500), scheduler: DispatchQueue.main)
            .tryMap { ok in
                if ok { return true }
                else { throw AuthError.invalidCredentials }
            }
            .eraseToAnyPublisher()
    }

    func signUp(email: String, password: String) -> AnyPublisher<Bool, Error> {
        guard password.count >= 8 else {
            return Fail(error: AuthError.weakPassword).eraseToAnyPublisher()
        }
        return Just(true)
            .delay(for: .milliseconds(600), scheduler: DispatchQueue.main)
            .setFailureType(to: Error.self)
            .eraseToAnyPublisher()
    }

    func sendOTP(to email: String) -> AnyPublisher<Bool, Error> {
        let ok = !email.isEmpty
        return Just(ok)
            .delay(for: .milliseconds(500), scheduler: DispatchQueue.main)
            .tryMap { ok in
                if ok { return true }
                else { throw AuthError.invalidCredentials }
            }
            .eraseToAnyPublisher()
    }

    func verifyOTP(email: String, code: String) -> AnyPublisher<Bool, Error> {
        let ok = code == "123456" || code.count == 6
        return Just(ok)
            .delay(for: .milliseconds(400), scheduler: DispatchQueue.main)
            .tryMap { ok in
                if ok { return true }
                else { throw AuthError.invalidCredentials }
            }
            .eraseToAnyPublisher()
    }

    func logout() -> AnyPublisher<Bool, Never> {
        Just(true).eraseToAnyPublisher()
    }
}
