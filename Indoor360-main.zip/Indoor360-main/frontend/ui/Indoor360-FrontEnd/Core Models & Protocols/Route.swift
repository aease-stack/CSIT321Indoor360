import Foundation

struct RouteStep: Identifiable, Hashable {
    let id = UUID()
    var instruction: String
    var distanceMeters: Double
    var estimatedSeconds: Double
}

struct Route: Identifiable, Hashable {
    let id = UUID()
    var steps: [RouteStep]
    var totalDistanceMeters: Double
    var totalEstimatedSeconds: Double
}
