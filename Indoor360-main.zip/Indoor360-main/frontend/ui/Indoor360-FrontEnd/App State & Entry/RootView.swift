import SwiftUI

/// Chooses which top-level screen to show based on AppState flags.
/// Order is strict: Onboarding → Permissions → Auth → Main.
struct RootView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        // Keep a single NavigationStack to avoid “two screens at once”
        NavigationStack {
            content
                .animation(.default, value: appState.hasCompletedOnboarding)
                .animation(.default, value: appState.hasCompletedCorePermissions)
                .animation(.default, value: appState.isAuthenticated)
        }
    }

    @ViewBuilder
    private var content: some View {
        if !appState.hasCompletedOnboarding {
            OnboardingView()
                .onAppear { debugLog("Route: Onboarding") }
        } else if !appState.hasCompletedCorePermissions {
            PermissionsView()
                .onAppear { debugLog("Route: Permissions") }
        } else if !appState.isAuthenticated {
            AuthView()
                .onAppear { debugLog("Route: Auth") }
        } else {
            // Main app container (tabs / home / map / more)
            RootRouterView()
                .onAppear { debugLog("Route: Main") }
        }
    }

    private func debugLog(_ s: String) {
        #if DEBUG
        print("RootView → \(s)")
        #endif
    }
}
