import SwiftUI
import Combine

/// Global application state shared across features.
/// - Accessibility: keeps Reduced Motion & High Contrast flags
/// - Session: onboarding, permissions & auth gates
final class AppState: ObservableObject {
    // Product/session
    @Published var hasCompletedOnboarding: Bool
    @Published var hasCompletedCorePermissions: Bool
    @Published var isAuthenticated: Bool
    @Published var isGuest: Bool = false

    // Accessibility & UI preferences
    @Published var prefersReducedMotion: Bool = UIAccessibility.isReduceMotionEnabled
    @Published var prefersHighContrast: Bool = UIAccessibility.isDarkerSystemColorsEnabled
    @Published var appTheme: ColorScheme? = nil   // nil = system

    // Routing
    @Published var startDestinationPOIId: String? = nil

    init() {
        self.hasCompletedOnboarding      = SettingsStore.loadOnboardingDone()
        self.hasCompletedCorePermissions = SettingsStore.loadCorePermissionsDone()
        self.isAuthenticated             = SettingsStore.loadIsAuthenticated()
        self.isGuest                     = SettingsStore.loadIsGuest()
        self.appTheme = SettingsStore.loadTheme()
    }
}
