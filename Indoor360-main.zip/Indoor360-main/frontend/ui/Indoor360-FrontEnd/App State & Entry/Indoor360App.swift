import SwiftUI

@main
struct Indoor360App: App {
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            RootRouterView()
                .environmentObject(appState)
                .onAppear {
                    appState.hasCompletedOnboarding      = SettingsStore.loadOnboardingDone()
                    appState.hasCompletedCorePermissions = SettingsStore.loadCorePermissionsDone()
                    appState.isAuthenticated             = SettingsStore.loadIsAuthenticated()
                    appState.isGuest                     = SettingsStore.loadIsGuest()
                    appState.appTheme                    = SettingsStore.loadTheme()
                }
        }
    }
}
