import SwiftUI

struct SectionHeader: View {
    var title: String
    var actionTitle: String? = nil
    var onAction: (() -> Void)? = nil

    var body: some View {
        HStack {
            Text(title)
                .font(Typography.headlineM)
                .foregroundColor(DSColor.textPrimary)
            Spacer()
            if let actionTitle, let onAction {
                Button(actionTitle, action: onAction)
                    .font(Typography.captionEmphasis)
                    .foregroundColor(DSColor.accent)
                    .minTapTarget()
            }
        }
        .padding(.horizontal, Space.lg)
    }
}

#Preview {
    SectionHeader(title: "Special Offers", actionTitle: "View All", onAction: {})
}
