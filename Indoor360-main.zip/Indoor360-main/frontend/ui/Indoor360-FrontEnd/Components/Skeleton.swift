import SwiftUI

struct Skeleton: View {
    var cornerRadius: CGFloat = 12
    var height: CGFloat = 16

    @State private var phase: CGFloat = -0.8

    var body: some View {
        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
            .fill(LinearGradient(
                colors: UIAccessibility.isReduceMotionEnabled
                    ? [DSColor.surface]
                    : [DSColor.surface.opacity(0.9), DSColor.surface, DSColor.surface.opacity(0.9)],
                startPoint: .leading, endPoint: .trailing)
            )
            .frame(height: height)
            .mask(
                Rectangle()
                    .fill(LinearGradient(
                        gradient: Gradient(stops: [
                            .init(color: .black.opacity(0.2), location: phase),
                            .init(color: .black, location: phase + 0.1),
                            .init(color: .black.opacity(0.2), location: phase + 0.2)
                        ]),
                        startPoint: .leading, endPoint: .trailing))
            )
            .onAppear {
                guard !UIAccessibility.isReduceMotionEnabled else { return }
                withAnimation(.linear(duration: 1.2).repeatForever(autoreverses: false)) {
                    phase = 1.0
                }
            }
    }
}

#Preview {
    VStack(spacing: 12) {
        Skeleton(height: 16)
        Skeleton(height: 16)
        Skeleton(cornerRadius: 16, height: 120)
    }
    .padding()
    .background(DSColor.background)
}
