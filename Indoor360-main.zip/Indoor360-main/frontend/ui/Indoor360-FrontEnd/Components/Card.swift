import SwiftUI

/// A reusable card container with Indoor360 styling
struct Card<Content: View>: View {
    let cornerRadius: CGFloat
    let content: Content
    
    init(cornerRadius: CGFloat = 20, @ViewBuilder content: () -> Content) {
        self.cornerRadius = cornerRadius
        self.content = content()
    }
    
    var body: some View {
        content
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .glassBackground(cornerRadius: cornerRadius)   // Frosted glass style
            .accessibilityElement(children: .contain)
    }
}

#Preview {
    VStack(spacing: 16) {
        Card {
            Text("Indoor360 Card Example")
                .font(.headline)
                .foregroundStyle(DSColor.textPrimary)
        }
        
        Card {
            VStack(alignment: .leading, spacing: 8) {
                Text("Offer Title")
                    .font(.title3)
                    .foregroundStyle(DSColor.textPrimary)
                Text("Offer details go here, styled inside a card.")
                    .font(.body)
                    .foregroundStyle(DSColor.textSecondary)
            }
        }
    }
    .padding()
    .background(AppBackgroundView()) // Brand gradient background
}
