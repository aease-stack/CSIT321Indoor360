import SwiftUI

struct OTPInput: View {
    let length: Int = 6
    @Binding var code: String
    var onComplete: ((String) -> Void)? = nil

    @FocusState private var focusedIndex: Int?

    var body: some View {
        HStack(spacing: 10) {
            ForEach(0..<length, id: \.self) { index in
                SingleCell(index: index,
                           character: char(at: index),
                           isFocused: focusedIndex == index)
                .onTapGesture { focusedIndex = index }
            }
        }
        .padding(.horizontal, Space.lg)
        .onAppear { if code.isEmpty { focusedIndex = 0 } }
        .background(HiddenTextField(text: $code,
                                    length: length,
                                    focusedIndex: $focusedIndex,
                                    onComplete: onComplete))
    }

    private func char(at index: Int) -> String {
        guard index < code.count else { return "" }
        let arr = Array(code)
        return String(arr[index])
    }

    // MARK: - Single Cell
    struct SingleCell: View {
        let index: Int
        let character: String
        let isFocused: Bool

        var body: some View {
            Text(character)
                .font(Typography.headlineM)
                .frame(width: 44, height: 52)
                .background(DSColor.surface)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(isFocused ? DSColor.accent : Color.clear, lineWidth: 2)
                )
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .accessibilityLabel(Text("Digit \(index + 1)"))
        }
    }

    // MARK: - Hidden collector
    struct HiddenTextField: UIViewRepresentable {
        @Binding var text: String
        let length: Int
        var focusedIndex: FocusState<Int?>.Binding
        var onComplete: ((String) -> Void)?

        func makeUIView(context: Context) -> UITextField {
            let tf = UITextField()
            tf.keyboardType = .numberPad
            tf.textContentType = .oneTimeCode
            tf.addTarget(context.coordinator, action: #selector(Coordinator.changed), for: .editingChanged)
            tf.isHidden = true
            return tf
        }

        func updateUIView(_ uiView: UITextField, context: Context) {
            if uiView.window != nil && !(uiView.isFirstResponder) {
                uiView.becomeFirstResponder()
            }
        }

        func makeCoordinator() -> Coordinator { Coordinator(self) }

        class Coordinator: NSObject {
            var parent: HiddenTextField
            init(_ parent: HiddenTextField) { self.parent = parent }

            @objc func changed(_ sender: UITextField) {
                let filtered = sender.text?.filter(\.isNumber) ?? ""
                parent.text = String(filtered.prefix(parent.length))
                let count = parent.text.count
                parent.focusedIndex.wrappedValue = min(count, parent.length - 1)
                if count == parent.length {
                    Haptics.confirm()
                    parent.onComplete?(parent.text)
                }
            }
        }
    }
}

#Preview {
    OTPInput(code: .constant(""))
}
