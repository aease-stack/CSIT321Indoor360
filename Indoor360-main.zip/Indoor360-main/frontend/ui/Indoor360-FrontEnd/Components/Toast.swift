import SwiftUI



// Local compatibility helper so this file always sees it

extension View {

    @ViewBuilder

    func onChangeCompat<T: Equatable>(

        of value: T,

        perform action: @escaping (_ oldValue: T?, _ newValue: T) -> Void

    ) -> some View {

        if #available(iOS 17, *) {

            self.onChange(of: value) { old, new in

                action(old, new)

            }

        } else {

            self.onChange(of: value) { new in

                action(nil, new)

            }

        }

    }

}

enum ToastStyle { case success, error, info }

struct ToastView: View {
    let style: ToastStyle
    let message: String

    var bg: Color {
        switch style {
        case .success: return DSColor.success
        case .error:   return DSColor.danger
        case .info:    return DSColor.accent
        }
    }

    var body: some View {
        Text(message)
            .font(Typography.body)
            .foregroundColor(.white)
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(bg)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .shadow(radius: 6, y: 2)
            .accessibilityAddTraits(.isStaticText)
    }
}

struct ToastModifier: ViewModifier {
    @Binding var isPresented: Bool
    let style: ToastStyle
    let message: String
    let duration: TimeInterval
    
    @State private var showNow = false
    
    func body(content: Content) -> some View {
        ZStack {
            content
            if showNow {
                VStack {
                    Spacer()
                    ToastView(style: style, message: message)
                        .padding(.bottom, 28)
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .onChangeCompat(of: isPresented) { _, presented in
            guard presented else { withAnimation { showNow = false } ; return }
            withAnimation(.easeOut(duration: UIAccessibility.isReduceMotionEnabled ? 0 : 0.25)) {
                showNow = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
                withAnimation { showNow = false }
                isPresented = false
            }
        }
    }
}
extension View {
    func toast(isPresented: Binding<Bool>,
               style: ToastStyle = .info,
               message: String,
               duration: TimeInterval = 2.0) -> some View {
        modifier(ToastModifier(isPresented: isPresented, style: style, message: message, duration: duration))
    }
}

#Preview {
    StatefulPreviewWrapper(true) { show in
        VStack {
            Text("Example")
            Spacer()
        }
        .toast(isPresented: show, style: .success, message: "Saved!")
    }
}

// Helper to preview @Binding
struct StatefulPreviewWrapper<Value, Content: View>: View {
    @State var value: Value
    var content: (Binding<Value>) -> Content
    init(_ value: Value, content: @escaping (Binding<Value>) -> Content) {
        _value = State(initialValue: value)
        self.content = content
    }
    var body: some View { content($value) }
}
