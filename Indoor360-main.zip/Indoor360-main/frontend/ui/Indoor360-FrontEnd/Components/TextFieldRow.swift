import SwiftUI

struct TextFieldRow: View {
    var title: String
    var placeholder: String
    @Binding var text: String
    var helper: String? = nil
    var error: String? = nil
    var keyboard: UIKeyboardType = .default
    var contentType: UITextContentType? = nil
    var textInputAutocapitalization: TextInputAutocapitalization = .never

    @FocusState private var isFocused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(Typography.captionEmphasis)
                .foregroundColor(DSColor.textPrimary)

            TextField(placeholder, text: $text)
                .keyboardType(keyboard)
                .textInputAutocapitalization(textInputAutocapitalization)
                .textContentType(contentType)
                .foregroundColor(DSColor.textPrimary)
                .tint(DSColor.accent)
                .padding(.horizontal, Space.md)
                .frame(minHeight: 52)
                .background(DSColor.surface)
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(error == nil ? Color.clear : DSColor.danger, lineWidth: 1)
                )
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .focused($isFocused)
                .accessibilityLabel(Text(title))

            if let error {
                Text(error)
                    .font(Typography.caption)
                    .foregroundColor(DSColor.danger)
            } else if let helper {
                Text(helper)
                    .font(Typography.caption)
                    .foregroundColor(DSColor.textSecondary)
            }
        }
        .padding(.horizontal, Space.lg)
    }
}

#Preview {
    VStack(spacing: 14) {
        TextFieldRow(title: "Email address",
                     placeholder: "name@example.com",
                     text: .constant(""),
                     helper: "We’ll never share your email.",
                     keyboard: .emailAddress,
                     contentType: .emailAddress)
        TextFieldRow(title: "Email address",
                     placeholder: "name@example.com",
                     text: .constant("wrong"),
                     error: "Please enter a valid email.")
    }
}
