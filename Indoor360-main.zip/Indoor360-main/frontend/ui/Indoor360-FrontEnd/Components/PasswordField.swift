import SwiftUI

struct PasswordField: View {
    var title: String = "Password"
    var placeholder: String = "Enter password"
    @Binding var text: String
    @State private var show: Bool = false
    var helper: String? = nil
    var error: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(Typography.captionEmphasis)
                .foregroundColor(DSColor.textPrimary)

            HStack {
                Group {
                    if show {
                        TextField(placeholder, text: $text)
                            .textContentType(.password)
                            .autocorrectionDisabled()
                            .foregroundColor(DSColor.accent)
                    } else {
                        SecureField(placeholder, text: $text)
                            .textContentType(.password)
                            .autocorrectionDisabled()
                            .foregroundColor(DSColor.textPrimary)
                            .tint(DSColor.accent)
                    }
                }
                Button(action: { show.toggle() }) {
                    Image(systemName: show ? "eye.slash" : "eye")
                        .foregroundColor(DSColor.textSecondary)
                        .frame(width: 36, height: 36)
                }
                .buttonStyle(.plain)
                .minTapTarget()
                .accessibilityLabel(Text(show ? "Hide password" : "Show password"))
            }
            .padding(.horizontal, Space.md)
            .frame(minHeight: 52)
            .background(DSColor.surface)
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(error == nil ? Color.clear : DSColor.danger, lineWidth: 1)
            )
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))

            if let error {
                Text(error)
                    .font(Typography.caption)
                    .foregroundColor(DSColor.danger)
            } else if let helper {
                Text(helper)
                    .font(Typography.caption)
                    .foregroundColor(DSColor.textSecondary)
            }
        }
        .padding(.horizontal, Space.lg)
    }
}

#Preview {
    VStack(spacing: 14) {
        PasswordField(text: .constant(""))
        PasswordField(text: .constant("short"), error: "Password too short.")
    }
}
