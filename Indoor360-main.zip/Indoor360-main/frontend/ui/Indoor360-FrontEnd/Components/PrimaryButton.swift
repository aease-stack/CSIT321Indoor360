import SwiftUI

struct PrimaryButton: View {
    var title: String
    var action: () -> Void
    var isLoading: Bool = false
    var isDisabled: Bool = false

    @Environment(\.colorScheme) private var scheme

    var body: some View {
        Button(action: { if !isLoading { action() } }) {
            ZStack {
                if isLoading {
                    ProgressView().progressViewStyle(.circular)
                        .tint(.white)
                        .voLabel("Loading")
                } else {
                    Text(title)
                        .font(Typography.bodyEmphasis)
                        .foregroundColor(.white)
                }
            }
            .frame(maxWidth: .infinity, minHeight: 52)
        }
        .buttonStyle(.plain)
        .background(DSColor.accent)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .shadow(color: Color.black.opacity(scheme == .dark ? 0.3 : 0.15), radius: 8, y: 2)
        .opacity(isDisabled ? 0.6 : 1.0)
        .disabled(isDisabled)
        .minTapTarget()
        .accessibilityHint(Text(isDisabled ? "Disabled" : ""))
    }
}

#Preview {
    VStack(spacing: 16) {
        PrimaryButton(title: "Continue", action: {})
        PrimaryButton(title: "Loading", action: {}, isLoading: true)
            .padding(.horizontal, 20)
    }
    .padding()
    .background(DSColor.background)
}
