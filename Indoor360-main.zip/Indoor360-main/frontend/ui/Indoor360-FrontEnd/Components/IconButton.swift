import SwiftUI

struct IconButton: View {
    var systemName: String
    var action: () -> Void
    var tint: Color = DSColor.textPrimary

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.title3)
                .foregroundColor(tint)
                .frame(width: AX.minTapSize, height: AX.minTapSize)
                .background(Color.clear)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(Text(systemName.replacingOccurrences(of: ".", with: " ")))
    }
}

#Preview {
    HStack {
        IconButton(systemName: "magnifyingglass", action: {})
        IconButton(systemName: "qrcode.viewfinder", action: {}, tint: DSColor.accent)
    }
}
