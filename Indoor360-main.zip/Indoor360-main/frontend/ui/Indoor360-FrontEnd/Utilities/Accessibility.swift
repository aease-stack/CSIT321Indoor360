import SwiftUI

enum AX {
    static let minTapSize: CGFloat = 44
}

extension View {
    /// Ensures a minimum tap target for interactive elements.
    func minTapTarget() -> some View {
        self.contentShape(Rectangle())
            .frame(minWidth: AX.minTapSize, minHeight: AX.minTapSize)
    }

    /// Sugar for setting an accessibility label succinctly.
    func voLabel(_ text: String) -> some View {
        accessibilityLabel(Text(text))
    }
}
