import UIKit

enum Haptics {
    // Granular impact styles
    static func light() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }
    static func medium() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }
    static func heavy() {
        UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
    }

    // Semantic aliases for clarity in flows
    static func confirm() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }
    static func reroute() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }
    static func critical() {
        UINotificationFeedbackGenerator().notificationOccurred(.error)
    }
}
