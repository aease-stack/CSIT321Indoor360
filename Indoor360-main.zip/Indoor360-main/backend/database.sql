-- =====================
-- CLEAN RESET
-- =====================
DROP SCHEMA public CASCADE;
CREATE SCHEMA public;

-- Enable PostGIS
CREATE EXTENSION IF NOT EXISTS postgis;

-- =====================
-- CORE: USERS & AUTH
-- =====================
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(150) UNIQUE,
    phone VARCHAR(20),
    password_hash TEXT,
    auth_provider VARCHAR(50),
    role VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE roles (
    role_id SERIAL PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE,
    description TEXT
);

CREATE TABLE user_roles (
    user_role_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(user_id) ON DELETE CASCADE,
    role_id INT REFERENCES roles(role_id) ON DELETE CASCADE,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE audit_logs (
    log_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(user_id),
    action VARCHAR(150),
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================
-- IMDF PACKAGE & FILES
-- =====================
CREATE TABLE imdf_packages (
    package_id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    version TEXT,
    uploaded_by INT REFERENCES users(user_id),
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE imdf_files (
    file_id SERIAL PRIMARY KEY,
    package_id INT REFERENCES imdf_packages(package_id) ON DELETE CASCADE,
    file_name TEXT NOT NULL,
    data JSONB NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================
-- SPATIAL CORE
-- =====================
CREATE TABLE buildings (
    id SERIAL PRIMARY KEY,
    imdf_id TEXT UNIQUE,
    package_id INT REFERENCES imdf_packages(package_id) ON DELETE CASCADE,
    name TEXT,
    address TEXT,
    description TEXT,
    geom GEOMETRY(Geometry, 4326)
);

CREATE INDEX idx_buildings_geom ON buildings USING GIST (geom);

CREATE TABLE floors (
    id SERIAL PRIMARY KEY,
    imdf_id TEXT UNIQUE,
    package_id INT REFERENCES imdf_packages(package_id) ON DELETE CASCADE,
    building_imdf_id TEXT,
    building_id INT REFERENCES buildings(id) ON DELETE CASCADE,
    ordinal INT,
    name TEXT,
    version TEXT,
    uploaded_by INT REFERENCES users(user_id),
    geom GEOMETRY(Geometry, 4326),
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_floors_geom ON floors USING GIST (geom);

CREATE TABLE pois (
    id SERIAL PRIMARY KEY,
    imdf_id TEXT UNIQUE,
    package_id INT REFERENCES imdf_packages(package_id) ON DELETE CASCADE,
    floor_imdf_id TEXT,
    floor_id INT REFERENCES floors(id) ON DELETE CASCADE,
    name TEXT,
    category TEXT,
    description TEXT,
    accessible_features TEXT,
    geom GEOMETRY(Point, 4326)
);

CREATE INDEX idx_pois_geom ON pois USING GIST (geom);

CREATE TABLE routes (
    id SERIAL PRIMARY KEY,
    imdf_id TEXT UNIQUE,
    package_id INT REFERENCES imdf_packages(package_id) ON DELETE CASCADE,
    start_poi_imdf_id TEXT,
    end_poi_imdf_id TEXT,
    start_poi_id INT REFERENCES pois(id),
    end_poi_id INT REFERENCES pois(id),
    geom GEOMETRY(LineString, 4326),
    distance_meters DOUBLE PRECISION,
    estimated_time_seconds INT
);

CREATE INDEX idx_routes_geom ON routes USING GIST (geom);

-- =====================
-- INDOOR POSITIONING
-- =====================
CREATE TABLE anchors (
    anchor_id SERIAL PRIMARY KEY,
    floor_id INT REFERENCES floors(id) ON DELETE CASCADE,
    imdf_id TEXT,
    geom GEOMETRY(Point, 4326),
    anchor_type VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE access_points (
    ap_id SERIAL PRIMARY KEY,
    building_id INT REFERENCES buildings(id) ON DELETE CASCADE,
    ssid VARCHAR(100),
    mac_address VARCHAR(50) UNIQUE,
    geom GEOMETRY(Point, 4326)
);

CREATE TABLE heatmap_readings (
    reading_id SERIAL PRIMARY KEY,
    floor_id INT REFERENCES floors(id) ON DELETE CASCADE,
    ap_id INT REFERENCES access_points(ap_id) ON DELETE CASCADE,
    geom GEOMETRY(Point, 4326),
    rssi_value INT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE sensor_data (
    sensor_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(user_id) ON DELETE CASCADE,
    type VARCHAR(50),
    reading JSONB,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================
-- APP LAYER
-- =====================
CREATE TABLE navigation_sessions (
    session_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(user_id),
    start_poi_id INT REFERENCES pois(id),
    end_poi_id INT REFERENCES pois(id),
    route_geom GEOMETRY(LineString, 4326),
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

CREATE TABLE feedback (
    feedback_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(user_id),
    poi_id INT REFERENCES pois(id),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'open'
);

CREATE TABLE poi_names (
    poi_name_id SERIAL PRIMARY KEY,
    poi_id INT REFERENCES pois(id) ON DELETE CASCADE,
    lang_code VARCHAR(10),
    name TEXT
);

SELECT * FROM imdf_files;


------------------------------------------

-- Import Buildings
CREATE OR REPLACE FUNCTION import_imdf_buildings(p_package_id INT)
RETURNS VOID AS $$
BEGIN
    INSERT INTO buildings (imdf_id, package_id, name, address, description, geom)
    SELECT DISTINCT ON (feat->>'id')
        feat->>'id' AS imdf_id,
        i.package_id,
        (feat->'properties'->'name'->>'en')::text,
        (feat->'properties'->>'address')::text,
        (feat->'properties'->>'description')::text,
        CASE
            WHEN (feat ? 'geometry') AND (feat->'geometry' IS NOT NULL) THEN
                ST_SetSRID(ST_Force2D(ST_GeomFromGeoJSON(feat->>'geometry')), 4326)
            ELSE NULL
        END
    FROM imdf_files i,
         jsonb_array_elements(i.data->'features') AS feat
    WHERE i.package_id = p_package_id
      AND i.file_name ILIKE '%building.geojson'
      AND feat->>'feature_type' = 'building'
    ON CONFLICT (imdf_id) DO UPDATE
    SET name = EXCLUDED.name,
        address = EXCLUDED.address,
        description = EXCLUDED.description,
        geom = EXCLUDED.geom;
END;
$$ LANGUAGE plpgsql;


-- Import Floors
CREATE OR REPLACE FUNCTION import_imdf_floors(p_package_id INT)
RETURNS VOID AS $$
BEGIN
    INSERT INTO floors (imdf_id, package_id, building_imdf_id, ordinal, name, version, geom)
    SELECT DISTINCT ON (feat->>'id')
        feat->>'id',
        i.package_id,
        feat->'properties'->>'building_id',
        (feat->'properties'->>'ordinal')::INT,
        (feat->'properties'->'name'->>'en')::text,
        (feat->'properties'->>'version')::text,
        ST_SetSRID(ST_Force2D(ST_GeomFromGeoJSON(feat->>'geometry')), 4326)
    FROM imdf_files i,
         jsonb_array_elements(i.data->'features') AS feat
    WHERE i.package_id = p_package_id
      AND i.file_name ILIKE '%level.geojson'
      AND feat->>'feature_type' IN ('level','floor')
    ON CONFLICT (imdf_id) DO UPDATE
    SET ordinal = EXCLUDED.ordinal,
        name = EXCLUDED.name,
        version = EXCLUDED.version,
        geom = EXCLUDED.geom;

    -- resolve building_id
    UPDATE floors f
    SET building_id = b.id
    FROM buildings b
    WHERE f.building_imdf_id = b.imdf_id
      AND f.building_id IS DISTINCT FROM b.id;
END;
$$ LANGUAGE plpgsql;


-- Import POIs
CREATE OR REPLACE FUNCTION import_imdf_pois(p_package_id INT)
RETURNS VOID AS $$
BEGIN
    INSERT INTO pois (imdf_id, package_id, floor_imdf_id, name, category, description, accessible_features, geom)
    SELECT DISTINCT ON (feat->>'id')
        feat->>'id',
        i.package_id,
        feat->'properties'->>'level_id',
        COALESCE(feat->'properties'->'name'->>'en', feat->'properties'->>'name'),
        feat->'properties'->>'category',
        feat->'properties'->>'description',
        feat->'properties'->>'accessible',
        ST_SetSRID(ST_Force2D(ST_GeomFromGeoJSON(feat->>'geometry')), 4326)
    FROM imdf_files i,
         jsonb_array_elements(i.data->'features') AS feat
    WHERE i.package_id = p_package_id
      AND i.file_name ILIKE '%poi.geojson'
      AND feat->>'feature_type' = 'poi'
    ON CONFLICT (imdf_id) DO UPDATE
    SET name = EXCLUDED.name,
        category = EXCLUDED.category,
        description = EXCLUDED.description,
        accessible_features = EXCLUDED.accessible_features,
        geom = EXCLUDED.geom,
        floor_imdf_id = EXCLUDED.floor_imdf_id;

    -- resolve floor_id
    UPDATE pois p
    SET floor_id = f.id
    FROM floors f
    WHERE p.floor_imdf_id = f.imdf_id
      AND p.floor_id IS DISTINCT FROM f.id;
END;
$$ LANGUAGE plpgsql;


-- Import Routes
CREATE OR REPLACE FUNCTION import_imdf_routes(p_package_id INT)
RETURNS VOID AS $$
BEGIN
    INSERT INTO routes (imdf_id, package_id, start_poi_imdf_id, end_poi_imdf_id, geom, distance_meters, estimated_time_seconds)
    SELECT DISTINCT ON (feat->>'id')
        feat->>'id',
        i.package_id,
        feat->'properties'->>'start',
        feat->'properties'->>'end',
        ST_SetSRID(ST_Force2D(ST_GeomFromGeoJSON(feat->>'geometry')), 4326),
        (feat->'properties'->>'distance')::double precision,
        (feat->'properties'->>'time')::INT
    FROM imdf_files i,
         jsonb_array_elements(i.data->'features') AS feat
    WHERE i.package_id = p_package_id
      AND i.file_name ILIKE '%route.geojson'
      AND feat->>'feature_type' = 'route'
    ON CONFLICT (imdf_id) DO UPDATE
    SET geom = EXCLUDED.geom,
        distance_meters = EXCLUDED.distance_meters,
        estimated_time_seconds = EXCLUDED.estimated_time_seconds,
        start_poi_imdf_id = EXCLUDED.start_poi_imdf_id,
        end_poi_imdf_id = EXCLUDED.end_poi_imdf_id;

    -- resolve start/end poi IDs
    UPDATE routes r
    SET start_poi_id = p.id
    FROM pois p
    WHERE r.start_poi_imdf_id = p.imdf_id;

    UPDATE routes r
    SET end_poi_id = p.id
    FROM pois p
    WHERE r.end_poi_imdf_id = p.imdf_id;
END;
$$ LANGUAGE plpgsql;



CREATE OR REPLACE FUNCTION import_imdf_pois(p_package_id INT)
RETURNS VOID AS $$
BEGIN
    INSERT INTO pois (imdf_id, package_id, floor_imdf_id, name, category, description, accessible_features, geom)
    SELECT DISTINCT ON (feat->>'id')
        feat->>'id',
        i.package_id,
        feat->'properties'->>'level_id',
        -- Use "name" field if exists, fallback to category/type
        COALESCE(feat->'properties'->'name'->>'en', feat->'properties'->>'name', feat->'properties'->>'category'),
        feat->'properties'->>'category',
        feat->'properties'->>'description',
        feat->'properties'->>'accessible',
        CASE
            WHEN (feat ? 'geometry') AND (feat->'geometry' IS NOT NULL) 
                THEN ST_SetSRID(ST_Force2D(ST_GeomFromGeoJSON(feat->>'geometry')), 4326)
            WHEN (feat->'properties'->'display_point'->'coordinates') IS NOT NULL
                THEN ST_SetSRID(ST_MakePoint(
                        (feat->'properties'->'display_point'->'coordinates'->>0)::double precision,
                        (feat->'properties'->'display_point'->'coordinates'->>1)::double precision
                     ), 4326)
            ELSE NULL
        END
    FROM imdf_files i,
         jsonb_array_elements(i.data->'features') AS feat
    WHERE i.package_id = p_package_id
      AND (
            i.file_name ILIKE '%poi.geojson' OR  -- standard POIs (if exist in future)
            i.file_name ILIKE '%unit.geojson' OR -- rooms, spaces
            i.file_name ILIKE '%amenity.geojson' -- amenities (optional, empty in your case now)
          )
      AND (feat->>'feature_type') IN ('poi', 'unit', 'amenity')
    ORDER BY feat->>'id'
    ON CONFLICT (imdf_id) DO UPDATE
    SET name = EXCLUDED.name,
        category = EXCLUDED.category,
        description = EXCLUDED.description,
        accessible_features = EXCLUDED.accessible_features,
        geom = EXCLUDED.geom,
        floor_imdf_id = EXCLUDED.floor_imdf_id;

    -- resolve floor_id
    UPDATE pois p
    SET floor_id = f.id
    FROM floors f
    WHERE p.floor_imdf_id = f.imdf_id
      AND p.floor_id IS DISTINCT FROM f.id;
END;
$$ LANGUAGE plpgsql;
-----
CREATE OR REPLACE FUNCTION import_imdf_pois(p_package_id INT)
RETURNS VOID AS $$
BEGIN
    INSERT INTO pois (imdf_id, package_id, floor_imdf_id, name, category, description, accessible_features, geom)
    SELECT DISTINCT ON (feat->>'id')
        feat->>'id',
        i.package_id,
        feat->'properties'->>'level_id',
        COALESCE(feat->'properties'->'name'->>'en',
                 feat->'properties'->>'name',
                 feat->'properties'->>'category'),
        feat->'properties'->>'category',
        feat->'properties'->>'description',
        feat->'properties'->>'accessibility',
        CASE
            WHEN (feat ? 'geometry') AND (feat->'geometry' IS NOT NULL) THEN
                CASE
                    WHEN feat->'geometry'->>'type' = 'Point' THEN
                        ST_SetSRID(ST_GeomFromGeoJSON(feat->>'geometry'), 4326)
                    ELSE
                        -- If Polygon, take its centroid for POI location
                        ST_Centroid(ST_SetSRID(ST_GeomFromGeoJSON(feat->>'geometry'), 4326))
                END
            ELSE NULL
        END
    FROM imdf_files i,
         jsonb_array_elements(i.data->'features') AS feat
    WHERE i.package_id = p_package_id
      AND (
            i.file_name ILIKE '%poi.geojson' OR
            i.file_name ILIKE '%unit.geojson' OR
            i.file_name ILIKE '%amenity.geojson'
          )
      AND (feat->>'feature_type') IN ('poi','unit','amenity')
    ORDER BY feat->>'id'
    ON CONFLICT (imdf_id) DO UPDATE
    SET name = EXCLUDED.name,
        category = EXCLUDED.category,
        description = EXCLUDED.description,
        accessible_features = EXCLUDED.accessible_features,
        geom = EXCLUDED.geom,
        floor_imdf_id = EXCLUDED.floor_imdf_id;

    -- Link POIs to their floor
    UPDATE pois p
    SET floor_id = f.id
    FROM floors f
    WHERE p.floor_imdf_id = f.imdf_id
      AND p.floor_id IS DISTINCT FROM f.id;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION import_imdf_pois(p_package_id INT)
RETURNS VOID AS $$
BEGIN
    INSERT INTO pois (imdf_id, package_id, floor_imdf_id, name, category, description, accessible_features, geom)
    SELECT DISTINCT ON (feat->>'id')
        feat->>'id',
        i.package_id,
        feat->'properties'->>'level_id',
        COALESCE(feat->'properties'->'name'->>'en',
                 feat->'properties'->>'name',
                 feat->'properties'->>'category'),
        feat->'properties'->>'category',
        feat->'properties'->>'description',
        feat->'properties'->>'accessibility',
        CASE
            WHEN feat->'geometry'->>'type' = 'Polygon'
                THEN ST_Centroid(ST_GeomFromGeoJSON(feat->>'geometry'))
            ELSE ST_GeomFromGeoJSON(feat->>'geometry')
        END
    FROM imdf_files i,
         jsonb_array_elements(i.data->'features') AS feat
    WHERE i.package_id = p_package_id
      AND feat->>'feature_type' IN ('poi','unit','amenity')
    ORDER BY feat->>'id'
    ON CONFLICT (imdf_id) DO UPDATE
    SET name = EXCLUDED.name,
        category = EXCLUDED.category,
        description = EXCLUDED.description,
        accessible_features = EXCLUDED.accessible_features,
        geom = EXCLUDED.geom,
        floor_imdf_id = EXCLUDED.floor_imdf_id;

    -- Link POIs to floors
    UPDATE pois p
    SET floor_id = f.id
    FROM floors f
    WHERE p.floor_imdf_id = f.imdf_id
      AND p.floor_id IS DISTINCT FROM f.id;
END;
$$ LANGUAGE plpgsql;


---------------------------------------------------------------

-- Show last 5 uploaded packages
SELECT package_id, name, uploaded_at
FROM imdf_packages
ORDER BY uploaded_at DESC
LIMIT 5;

-- Show all files inside the latest package
SELECT file_id, file_name, uploaded_at
FROM imdf_files
WHERE package_id = (SELECT MAX(package_id) FROM imdf_packages);


-- Count how many buildings imported
SELECT COUNT(*) AS building_count FROM buildings;

-- Sample of buildings with geometry
SELECT id, imdf_id, name, address, ST_AsText(geom) AS geom
FROM buildings
LIMIT 10;


-- Count floors per building
SELECT b.name AS building_name, COUNT(f.id) AS floor_count
FROM buildings b
LEFT JOIN floors f ON f.building_id = b.id
GROUP BY b.name;

-- Sample floor data
SELECT id, imdf_id, ordinal, name, building_id, ST_AsText(geom) AS geom
FROM floors
LIMIT 10;


SELECT file_name, jsonb_array_length(data->'features') AS feature_count
FROM imdf_files
WHERE file_name ILIKE '%unit.geojson%'
  AND package_id = (SELECT MAX(package_id) FROM imdf_packages);

SELECT jsonb_pretty(data->'features'->0)
FROM imdf_files
WHERE file_name ILIKE '%unit.geojson%'
  AND package_id = (SELECT MAX(package_id) FROM imdf_packages);

SELECT DISTINCT feat->>'feature_type' AS feature_type
FROM imdf_files f,
     jsonb_array_elements(f.data->'features') AS feat
WHERE f.file_name ILIKE '%unit.geojson%'
  AND f.package_id = (SELECT MAX(package_id) FROM imdf_packages);


---
SELECT feat->>'id' AS imdf_id,
       feat->>'feature_type' AS feature_type,
       feat->'properties'->>'level_id' AS level_id,
       feat->'properties'->>'category' AS category,
       ST_AsText(
         CASE
           WHEN feat->'geometry'->>'type' = 'Polygon'
             THEN ST_Centroid(ST_GeomFromGeoJSON(feat->>'geometry'))
           ELSE ST_GeomFromGeoJSON(feat->>'geometry')
         END
       ) AS geom
FROM imdf_files i,
     jsonb_array_elements(i.data->'features') AS feat
WHERE i.file_name ILIKE '%unit.geojson%'
  AND i.package_id = (SELECT MAX(package_id) FROM imdf_packages)
LIMIT 5;


SELECT import_imdf_pois((SELECT MAX(package_id) FROM imdf_packages));

SELECT * FROM pois LIMIT 5;


CREATE OR REPLACE FUNCTION import_imdf_pois(p_package_id INT)
RETURNS VOID AS $$
BEGIN
    INSERT INTO pois (imdf_id, package_id, floor_imdf_id, name, category, geom)
    SELECT feat->>'id',
           i.package_id,
           feat->'properties'->>'level_id',
           feat->'properties'->>'category',
           feat->'properties'->>'category',
           ST_Centroid(ST_GeomFromGeoJSON(feat->>'geometry'))
    FROM imdf_files i,
         jsonb_array_elements(i.data->'features') AS feat
    WHERE i.package_id = p_package_id
      AND feat->>'feature_type' = 'unit';
END;
$$ LANGUAGE plpgsql;

SELECT import_imdf_pois((SELECT MAX(package_id) FROM imdf_packages));
SELECT COUNT(*) FROM pois;



CREATE OR REPLACE FUNCTION import_imdf_pois(p_package_id INT)
RETURNS VOID AS $$
BEGIN
    INSERT INTO pois (imdf_id, package_id, floor_imdf_id, name, category, geom)
    SELECT feat->>'id',
           i.package_id,
           feat->'properties'->>'level_id',
           COALESCE(feat->'properties'->'name'->>'en',
                    feat->'properties'->>'name',
                    feat->'properties'->>'category'),
           feat->'properties'->>'category',
           CASE
               WHEN feat->'geometry'->>'type' = 'Polygon'
                   THEN ST_Centroid(ST_GeomFromGeoJSON(feat->>'geometry'))
               ELSE ST_GeomFromGeoJSON(feat->>'geometry')
           END
    FROM imdf_files i,
         jsonb_array_elements(i.data->'features') AS feat
    WHERE i.package_id = p_package_id
      AND feat->>'feature_type' = 'unit'
    ON CONFLICT (imdf_id) DO UPDATE
    SET name = EXCLUDED.name,
        category = EXCLUDED.category,
        floor_imdf_id = EXCLUDED.floor_imdf_id,
        geom = EXCLUDED.geom;
END;
$$ LANGUAGE plpgsql;


SELECT import_imdf_pois((SELECT MAX(package_id) FROM imdf_packages));
SELECT COUNT(*) FROM pois;
SELECT id, imdf_id, name, category, ST_AsText(geom) FROM pois LIMIT 5;



CREATE OR REPLACE FUNCTION import_imdf_routes(p_package_id INT)
RETURNS VOID AS $$
BEGIN
    INSERT INTO routes (imdf_id, package_id, start_poi_imdf_id, end_poi_imdf_id, geom, distance_meters, estimated_time_seconds)
    SELECT DISTINCT ON (feat->>'id')
        feat->>'id',
        i.package_id,
        feat->'properties'->>'from_id',
        feat->'properties'->>'to_id',
        -- Build a simple line between centroids of connected POIs
        CASE
            WHEN p1.geom IS NOT NULL AND p2.geom IS NOT NULL
                THEN ST_MakeLine(p1.geom, p2.geom)
            ELSE NULL
        END,
        NULL::double precision,  -- Distance can be calculated later
        NULL::int                -- Time can be estimated later
    FROM imdf_files i,
         jsonb_array_elements(i.data->'features') AS feat
         LEFT JOIN pois p1 ON p1.imdf_id = feat->'properties'->>'from_id'
         LEFT JOIN pois p2 ON p2.imdf_id = feat->'properties'->>'to_id'
    WHERE i.package_id = p_package_id
      AND i.file_name ILIKE '%relationship.geojson%'
      AND feat->>'feature_type' = 'relationship'
    ORDER BY feat->>'id'
    ON CONFLICT (imdf_id) DO UPDATE
    SET start_poi_imdf_id = EXCLUDED.start_poi_imdf_id,
        end_poi_imdf_id = EXCLUDED.end_poi_imdf_id,
        geom = EXCLUDED.geom;
END;
$$ LANGUAGE plpgsql;


SELECT import_imdf_routes((SELECT MAX(package_id) FROM imdf_packages));

SELECT id, imdf_id, start_poi_id, end_poi_id, ST_AsText(geom)
FROM routes
LIMIT 10;



SELECT jsonb_pretty(feat)
FROM imdf_files f,
     jsonb_array_elements(f.data->'features') AS feat
WHERE f.file_name ILIKE '%relationship.geojson%'
  AND f.package_id = (SELECT MAX(package_id) FROM imdf_packages)
LIMIT 5;



CREATE OR REPLACE FUNCTION import_imdf_routes(p_package_id INT)
RETURNS VOID AS $$
BEGIN
  INSERT INTO routes
    (imdf_id, package_id,
     start_poi_imdf_id, end_poi_imdf_id,
     start_poi_id, end_poi_id,
     geom, distance_meters, estimated_time_seconds)
  SELECT DISTINCT ON (feat->>'id')
    feat->>'id'                                  AS imdf_id,
    i.package_id,
    feat->'properties'->>'from_id'               AS start_imdf,
    feat->'properties'->>'to_id'                 AS end_imdf,
    p1.id                                        AS start_poi_id,
    p2.id                                        AS end_poi_id,
    ST_MakeLine(p1.geom, p2.geom)                AS geom,
    ST_Length(ST_MakeLine(p1.geom, p2.geom)::geography) AS distance_meters,
    NULL::INT                                    AS estimated_time_seconds
  FROM imdf_files i
  JOIN LATERAL jsonb_array_elements(i.data->'features') AS feat ON TRUE
  JOIN pois p1 ON p1.imdf_id = (feat->'properties'->>'from_id')
  JOIN pois p2 ON p2.imdf_id = (feat->'properties'->>'to_id')
  WHERE i.package_id = p_package_id
    AND i.file_name ILIKE '%relationship.geojson%'
    AND (feat->>'feature_type') = 'relationship'
  ORDER BY feat->>'id'
  ON CONFLICT (imdf_id) DO UPDATE
  SET start_poi_imdf_id = EXCLUDED.start_poi_imdf_id,
      end_poi_imdf_id   = EXCLUDED.end_poi_imdf_id,
      start_poi_id      = EXCLUDED.start_poi_id,
      end_poi_id        = EXCLUDED.end_poi_id,
      geom              = EXCLUDED.geom,
      distance_meters   = EXCLUDED.distance_meters;
END;
$$ LANGUAGE plpgsql;



SELECT imdf_id, name, category
FROM pois
LIMIT 20;


CREATE OR REPLACE FUNCTION import_imdf_pois(p_package_id INT)
RETURNS VOID AS $$
BEGIN
  -- units / openings / fixtures / amenity / kiosk
  INSERT INTO pois (imdf_id, package_id, floor_imdf_id, name, category, description, accessible_features, geom, source_type)
  SELECT DISTINCT ON (feat->>'id')
    feat->>'id',
    i.package_id,
    COALESCE(feat->'properties'->>'level_id',
             feat->'properties'->>'level_ids'), -- some files use 'level_ids'
    COALESCE(feat->'properties'->'name'->>'en',
             feat->'properties'->>'name',
             feat->'properties'->>'category'),
    COALESCE(feat->'properties'->>'category', feat->>'feature_type'),
    feat->'properties'->>'description',
    COALESCE(feat->'properties'->>'accessibility', feat->'properties'->>'accessible'),
    CASE
      WHEN feat->'geometry'->>'type' = 'Point'
        THEN ST_SetSRID(ST_GeomFromGeoJSON(feat->>'geometry'), 4326)
      WHEN feat->'geometry'->>'type' IN ('Polygon','MultiPolygon')
        THEN ST_PointOnSurface(ST_SetSRID(ST_GeomFromGeoJSON(feat->>'geometry'), 4326))
      WHEN feat->'geometry'->>'type' IN ('LineString','MultiLineString')
        THEN ST_LineInterpolatePoint(ST_SetSRID(ST_GeomFromGeoJSON(feat->>'geometry'),4326), 0.5)
      ELSE NULL
    END,
    feat->>'feature_type'  -- source_type
  FROM imdf_files i
  JOIN LATERAL jsonb_array_elements(i.data->'features') AS feat ON TRUE
  WHERE i.package_id = p_package_id
    AND i.file_name ILIKE ANY (ARRAY[
          '%unit.geojson%',
          '%opening.geojson%',
          '%fixture.geojson%',
          '%amenity.geojson%',
          '%kiosk.geojson%'
        ])
    AND (feat->>'feature_type') IN ('unit','opening','fixture','amenity','kiosk')
  ORDER BY feat->>'id'
  ON CONFLICT (imdf_id) DO UPDATE
  SET name               = EXCLUDED.name,
      category           = EXCLUDED.category,
      description        = EXCLUDED.description,
      accessible_features= EXCLUDED.accessible_features,
      geom               = EXCLUDED.geom,
      floor_imdf_id      = EXCLUDED.floor_imdf_id,
      source_type        = EXCLUDED.source_type;

  -- link to floor (if present)
  UPDATE pois p
  SET floor_id = f.id
  FROM floors f
  WHERE p.floor_imdf_id = f.imdf_id
    AND p.floor_id IS DISTINCT FROM f.id;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION import_imdf_routes(p_package_id INT)
RETURNS VOID AS $$
BEGIN
  INSERT INTO routes
    (imdf_id, package_id,
     start_poi_imdf_id, end_poi_imdf_id,
     start_poi_id, end_poi_id,
     geom, distance_meters, estimated_time_seconds)
  SELECT DISTINCT ON (feat->>'id')
    feat->>'id'                                  AS imdf_id,
    i.package_id,
    feat->'properties'->>'from_id'               AS start_imdf,
    feat->'properties'->>'to_id'                 AS end_imdf,
    p1.id                                        AS start_poi_id,
    p2.id                                        AS end_poi_id,
    ST_MakeLine(p1.geom, p2.geom)                AS geom,
    ST_Length(ST_MakeLine(p1.geom, p2.geom)::geography) AS distance_meters,
    NULL::INT
  FROM imdf_files i
  JOIN LATERAL jsonb_array_elements(i.data->'features') AS feat ON TRUE
  JOIN pois p1 ON p1.imdf_id = (feat->'properties'->>'from_id')
  JOIN pois p2 ON p2.imdf_id = (feat->'properties'->>'to_id')
  WHERE i.package_id = p_package_id
    AND i.file_name ILIKE '%relationship.geojson%'
    AND (feat->>'feature_type') = 'relationship'
  ORDER BY feat->>'id'
  ON CONFLICT (imdf_id) DO UPDATE
  SET start_poi_imdf_id = EXCLUDED.start_poi_imdf_id,
      end_poi_imdf_id   = EXCLUDED.end_poi_imdf_id,
      start_poi_id      = EXCLUDED.start_poi_id,
      end_poi_id        = EXCLUDED.end_poi_id,
      geom              = EXCLUDED.geom,
      distance_meters   = EXCLUDED.distance_meters;
END;
$$ LANGUAGE plpgsql;


SELECT import_imdf_routes((SELECT MAX(package_id) FROM imdf_packages));


-- How many routes resolved?
SELECT COUNT(*) FROM routes WHERE start_poi_id IS NOT NULL AND end_poi_id IS NOT NULL;

-- Sample routes
SELECT id, start_poi_id, end_poi_id,
       ROUND(distance_meters::numeric, 2) AS meters
FROM routes
WHERE geom IS NOT NULL
LIMIT 15;



-- endpoints that didn’t match any POI
WITH rel AS (
  SELECT feat->'properties'->>'from_id' AS from_id,
         feat->'properties'->>'to_id'   AS to_id
  FROM imdf_files i
  JOIN LATERAL jsonb_array_elements(i.data->'features') AS feat ON TRUE
  WHERE i.package_id = (SELECT MAX(package_id) FROM imdf_packages)
    AND i.file_name ILIKE '%relationship.geojson%'
)
SELECT r.from_id, r.to_id
FROM rel r
LEFT JOIN pois p1 ON p1.imdf_id = r.from_id
LEFT JOIN pois p2 ON p2.imdf_id = r.to_id
WHERE p1.id IS NULL OR p2.id IS NULL
LIMIT 20;


ALTER TABLE pois
ADD COLUMN source_type TEXT;


SELECT import_imdf_pois((SELECT MAX(package_id) FROM imdf_packages));


SELECT source_type, COUNT(*) 
FROM pois 
GROUP BY source_type;

SELECT imdf_id, name, category, source_type 
FROM pois 
ORDER BY source_type, name 
LIMIT 20;

SELECT import_imdf_routes((SELECT MAX(package_id) FROM imdf_packages));


SELECT file_name, jsonb_array_length(data->'features') AS feature_count
FROM imdf_files
WHERE file_name IN ('opening.geojson','fixture.geojson')
  AND package_id = (SELECT MAX(package_id) FROM imdf_packages);


SELECT jsonb_pretty(data->'features'->0)
FROM imdf_files
WHERE file_name = 'opening.geojson'
  AND package_id = (SELECT MAX(package_id) FROM imdf_packages);

SELECT source_type, COUNT(*) 
FROM pois 
GROUP BY source_type;


SELECT imdf_id, name, category, source_type, ST_AsText(geom)
FROM pois
WHERE source_type IN ('opening','fixture')
LIMIT 10;


SELECT jsonb_pretty(feat)
FROM imdf_files f,
     jsonb_array_elements(f.data->'features') AS feat
WHERE f.file_name = 'relationship.geojson'
  AND f.package_id = (SELECT MAX(package_id) FROM imdf_packages)
LIMIT 3;

SELECT jsonb_pretty(feat->'properties')
FROM imdf_files f,
     jsonb_array_elements(f.data->'features') AS feat
WHERE f.file_name = 'relationship.geojson'
  AND f.package_id = (SELECT MAX(package_id) FROM imdf_packages)
LIMIT 3;

CREATE OR REPLACE FUNCTION import_imdf_routes(p_package_id INT)
RETURNS VOID AS $$
BEGIN
  INSERT INTO routes
    (imdf_id, package_id,
     start_poi_imdf_id, end_poi_imdf_id,
     start_poi_id, end_poi_id,
     geom, distance_meters)
  SELECT DISTINCT ON (feat->>'id')
    feat->>'id',
    i.package_id,
    feat->'properties'->'origin'->>'feature_id',
    feat->'properties'->'destination'->>'feature_id',
    p1.id,
    p2.id,
    ST_MakeLine(p1.geom, p2.geom),
    ST_Length(ST_MakeLine(p1.geom, p2.geom)::geography)
  FROM imdf_files i
  JOIN LATERAL jsonb_array_elements(i.data->'features') AS feat ON TRUE
  JOIN pois p1 ON p1.imdf_id = (feat->'properties'->'origin'->>'feature_id')
  JOIN pois p2 ON p2.imdf_id = (feat->'properties'->'destination'->>'feature_id')
  WHERE i.package_id = p_package_id
    AND i.file_name ILIKE '%relationship.geojson%'
  ORDER BY feat->>'id'
  ON CONFLICT (imdf_id) DO UPDATE
  SET start_poi_id    = EXCLUDED.start_poi_id,
      end_poi_id      = EXCLUDED.end_poi_id,
      geom            = EXCLUDED.geom,
      distance_meters = EXCLUDED.distance_meters;
END;
$$ LANGUAGE plpgsql;




CREATE OR REPLACE FUNCTION import_imdf_routes(p_package_id INT)
RETURNS VOID AS $$
BEGIN
  INSERT INTO routes
    (imdf_id, package_id,
     start_poi_imdf_id, end_poi_imdf_id,
     start_poi_id, end_poi_id,
     geom, distance_meters, estimated_time_seconds)
  SELECT DISTINCT ON (feat->>'id')
    feat->>'id' AS imdf_id,
    i.package_id,
    feat->'properties'->'origin'->>'feature_id'      AS start_imdf,
    feat->'properties'->'destination'->>'feature_id' AS end_imdf,
    p1.id                                            AS start_poi_id,
    p2.id                                            AS end_poi_id,
    ST_MakeLine(p1.geom, p2.geom)                    AS geom,
    ST_Length(ST_MakeLine(p1.geom, p2.geom)::geography) AS distance_meters,
    NULL::INT
  FROM imdf_files i
  JOIN LATERAL jsonb_array_elements(i.data->'features') AS feat ON TRUE
  JOIN pois p1 ON p1.imdf_id = (feat->'properties'->'origin'->>'feature_id')
  JOIN pois p2 ON p2.imdf_id = (feat->'properties'->'destination'->>'feature_id')
  WHERE i.package_id = p_package_id
    AND i.file_name ILIKE '%relationship.geojson%'
  ORDER BY feat->>'id'
  ON CONFLICT (imdf_id) DO UPDATE
  SET start_poi_id    = EXCLUDED.start_poi_id,
      end_poi_id      = EXCLUDED.end_poi_id,
      geom            = EXCLUDED.geom,
      distance_meters = EXCLUDED.distance_meters;
END;
$$ LANGUAGE plpgsql;



SELECT import_imdf_routes((SELECT MAX(package_id) FROM imdf_packages));




SELECT r.from_id, r.to_id,
       p1.source_type AS from_type,
       p2.source_type AS to_type
FROM rel r
LEFT JOIN pois p1 ON p1.imdf_id = r.from_id
LEFT JOIN pois p2 ON p2.imdf_id = r.to_id
LIMIT 20;




--------------------------------------------------------------------
--testing 


-- Recent packages
SELECT package_id, name, uploaded_at
FROM imdf_packages
ORDER BY uploaded_at DESC
LIMIT 2;

-- Files inside the latest package
SELECT file_id, file_name, jsonb_array_length(data->'features') AS feature_count
FROM imdf_files
WHERE package_id = (SELECT MAX(package_id) FROM imdf_packages);



-- Check building data
SELECT id, imdf_id, name, address, ST_AsText(geom) AS geom
FROM buildings
LIMIT 1;

-- Count buildings
SELECT COUNT(*) AS total_buildings FROM buildings;




-- Count floors
SELECT COUNT(*) AS total_floors FROM floors;

-- Count POIs by type
SELECT source_type, COUNT(*) 
FROM pois
GROUP BY source_type;

-- Sample POIs
SELECT id, imdf_id, name, category, source_type, ST_AsText(geom) AS geom
FROM pois
LIMIT 10;


SELECT p.id, p.name, p.category, p.source_type, ST_AsText(p.geom)
FROM pois p
WHERE p.floor_id = (SELECT id FROM floors LIMIT 1);

SELECT COUNT(*) AS total_routes,
       COUNT(*) FILTER (WHERE start_poi_id IS NOT NULL AND end_poi_id IS NOT NULL) AS valid_routes
FROM routes;


