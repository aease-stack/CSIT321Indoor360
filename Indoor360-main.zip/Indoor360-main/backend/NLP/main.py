# main.py
import os, json, sys, re
from typing import Optional, Tuple, List, Dict, Any

# ---- your NLU utilities (from preprocess.py) ----
from preprocess import (
    Preprocessor, detect_lang, build_json_lookup,
    match_json_name_or_family, norm_json_name
)

# === EDIT THIS PATH IF NEEDED ===
IMDF_PATH = r"C:\Users\hhs39\OneDrive - University of Wollongong\Desktop\1\.vscode\FINALNLP\unit (1).geojson"

# --- runtime knobs ---
PHRASE_TIME_LIMIT_SECONDS = 7
MAX_UTTERANCES = 4
DEBUG = True

# If you want to lock to a specific mic, set its index here (int). None = auto-pick
MIC_INDEX: Optional[int] = None

# Ensure UTF-8 console (Windows safe)
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# ----- SpeechRecognition import & mic checks -----
HAVE_SR = True
try:
    import speech_recognition as sr
except Exception as e:
    HAVE_SR = False
    print("[ERROR] Importing SpeechRecognition failed:", e)


def list_mics() -> List[str]:
    """Return and print available audio devices (names)."""
    if not HAVE_SR:
        return []
    try:
        names = sr.Microphone.list_microphone_names() or []
        if DEBUG:
            if not names:
                print("[DEBUG] No microphone devices reported by Windows.")
            else:
                print("[DEBUG] Audio devices:")
                for i, n in enumerate(names):
                    print(f"  {i}: {n}")
        return names
    except Exception as e:
        if DEBUG:
            print("[DEBUG] list_mics error:", e)
        return []


def choose_mic_index() -> Optional[int]:
    """Heuristic: pick a device that looks like a mic/headset; else default (None)."""
    names = list_mics()
    if not names:
        return None
    for i, n in enumerate(names):
        if re.search(r"(mic|microphone|headset|usb audio)", n or "", re.I):
            return i
    return None  # default device


def mic_available() -> Tuple[bool, Optional[str], Optional[int]]:
    """Check if default (or chosen) mic can open. Return (ok, reason_if_not, device_index_used)."""
    if not HAVE_SR:
        return False, "SpeechRecognition not installed", None
    try:
        idx = MIC_INDEX if MIC_INDEX is not None else choose_mic_index()
        # Try opening once
        with sr.Microphone(device_index=idx) as _:
            pass
        return True, None, idx
    except Exception as e:
        return False, str(e), None


# ----- Text fallback helper -----
def recognize_once_text() -> str:
    t = input("Type your request (press Enter to speak): ").strip()
    return t


# ----- IMDF loader -----
def load_imdf_units(path: str) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        raise FileNotFoundError(f"IMDF not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        gj = json.load(f)
    units: List[Dict[str, Any]] = []
    for ft in gj.get("features", []):
        props = ft.get("properties", {}) or {}
        fid = ft.get("id") or props.get("id")
        units.append({
            "id": fid,
            "name": props.get("name"),
            "alt_name": props.get("alt_name"),
            "category": props.get("category"),
            "level_id": props.get("level_id"),
        })
    return units


# ----- Shared speech capture (no fixed sample_rate) -----
def recognize_once_all(recognizer: "sr.Recognizer",
                       phrase_time_limit: int = PHRASE_TIME_LIMIT_SECONDS,
                       device_index: Optional[int] = None) -> List[Tuple[str, str]]:
    """
    Capture once, then try multilingual recognition.
    Returns list of (lang_code, transcript) pairs.
    """
    with sr.Microphone(device_index=device_index) as source:
        if DEBUG:
            print(f"[DEBUG] Listening on device: {device_index if device_index is not None else 'default'}")
        print("Speak now (Arabic or English)...")
        recognizer.adjust_for_ambient_noise(source, duration=1.0)
        audio = recognizer.listen(source, timeout=None, phrase_time_limit=phrase_time_limit)

    langs = ["ar-SA", "ar-EG", "en-US", "en-GB"]
    outs: List[Tuple[str, str]] = []
    for lg in langs:
        try:
            txt = recognizer.recognize_google(audio, language=lg, show_all=False)
            if isinstance(txt, str):
                t = txt.strip()
                if t and (lg, t) not in outs:
                    outs.append((lg, t))
        except Exception:
            # ignore bad lang hypotheses
            pass
    return outs


# === NLU core: text -> JSON payload ===
def process_query(text: str,
                  lookup: Dict[str, Any],
                  ar_pre: Preprocessor, en_pre: Preprocessor,
                  norm_to_record: Dict[str, Dict[str, Any]],
                  units: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not text:
        return None

    room_match, fam_match = match_json_name_or_family(
        text=text, lookup=lookup, ar_pre=ar_pre, en_pre=en_pre,
        jaccard_min=0.36, max_lev_ratio=0.22
    )

    # Exact/strong room match
    if room_match:
        norm_key = norm_json_name(room_match["norm"])
        rec = norm_to_record.get(norm_key) or norm_to_record.get(norm_json_name(room_match["name"]))

        # Special: "restroom 1" → "Restroom1"
        if not rec and room_match["norm"].startswith("restroom "):
            num = ''.join(ch for ch in room_match["norm"] if ch.isdigit())
            pretty = f"Restroom{num}" if num else None
            if pretty:
                rec = next((u for u in units if (u.get("name") or "").lower() == pretty.lower()), None)

        if not rec:
            return None

        return {
            "intent": "ROOM_NAV",
            "id": rec.get("id"),
            "name": rec.get("name"),
            "category": rec.get("category"),
            "level_id": rec.get("level_id"),
            "target": rec.get("name"),
            "score": round(float(room_match.get("score", 1.0)), 3)
        }

    # Family/category match: return options list
    if fam_match:
        base = fam_match["family"]
        options_norm = lookup["family_catalog"].get(base, [])
        options: List[str] = []
        for o in options_norm:
            rr = norm_to_record.get(o)
            if rr:
                options.append(rr["name"])
        if options:
            return {"intent": "FAMILY_LIST", "family": base, "options": options}

    return None


def main():
    # Show which Python we’re using (helps avoid the wrong interpreter)
    print("[DEBUG] Python exe:", sys.executable)

    # Confirm we are importing the local preprocess module
    if DEBUG:
        import preprocess as mod
        print("[DEBUG] Using preprocess module from:", getattr(mod, "__file__", "?"))

    # Load IMDF
    try:
        units = load_imdf_units(IMDF_PATH)
    except Exception as e:
        print(f"[FATAL] Could not load IMDF: {e}")
        return

    print(f"Loaded {len(units)} units from {IMDF_PATH}")
    if not units:
        print("No features in IMDF.")
        return

    # Build lookup catalogs
    lookup = build_json_lookup([{"name": u["name"], "alt_name": u["alt_name"]} for u in units])

    # Map normalized name → full record (for resolving back to pretty names)
    norm_to_record: Dict[str, Dict[str, Any]] = {}
    for u in units:
        if u.get("name"):
            norm_to_record[norm_json_name(u["name"])] = u
        if u.get("alt_name"):
            norm_to_record[norm_json_name(u["alt_name"])] = u

    if DEBUG:
        fams = lookup["family_catalog"]
        print("[DEBUG] Families available:", {k: v for k, v in fams.items() if v})
        print("[DEBUG] Has RESTROOM family?", "restroom" in fams and len(fams.get("restroom", [])) > 0)

    # Preprocessors
    ar_pre = Preprocessor("ar")
    en_pre = Preprocessor("en")

    # Decide voice vs text at runtime
    use_sr = False
    device_index: Optional[int] = None
    if HAVE_SR:
        ok, reason, idx = mic_available()
        if ok:
            use_sr = True
            device_index = idx
        else:
            print(f"Mic not available: {reason}. Falling back to text input.")
    else:
        print("SpeechRecognition not installed. Falling back to text input.")

    # Recognizer config (only if using voice)
    r = sr.Recognizer() if use_sr else None
    if r:
        r.energy_threshold = 250
        r.dynamic_energy_threshold = True
        r.pause_threshold = 1.0
        r.phrase_threshold = 0.25
        r.non_speaking_duration = 0.6

    # UI hints
    print("Type a request or press Enter to speak (Arabic or English).")
    print("- Examples: meeting / اجتماعات, elevator/مصعد/اسانسير/لفت, phone/booth/بوث, quiet/وايت روم, lab/لاب, restroom/حمام")
    print("- Exact names: control room, theatre, studio, luggage storage, board room, restroom 1/2")
    print(f"This session will handle {MAX_UTTERANCES} requests, then exit.\n")

    turns = 0
    try:
        while turns < MAX_UTTERANCES:
            payload: Optional[Dict[str, Any]] = None

            # 1) First check for typed text
            typed = recognize_once_text()

            if typed:
                if DEBUG:
                    print(f"[DEBUG] typed: {typed}")
                payload = process_query(typed, lookup, ar_pre, en_pre, norm_to_record, units)

            # 2) If nothing typed and voice available, listen once
            elif use_sr:
                hyps = recognize_once_all(r, phrase_time_limit=PHRASE_TIME_LIMIT_SECONDS, device_index=device_index)  # type: ignore[arg-type]
                if not hyps:
                    print("Did not catch that. Try again.")
                    turns += 1
                    continue

                for lg, t in hyps:
                    print(f"Transcript [{lg}]: {t}")
                # try each hypothesis until one resolves
                for _, t in hyps:
                    payload = process_query(t, lookup, ar_pre, en_pre, norm_to_record, units)
                    if payload:
                        break

            else:
                print("Mic unavailable. Please type your request.")
                turns += 1
                continue

            turns += 1

            if payload:
                print("JSON:", json.dumps(payload, ensure_ascii=False))
            else:
                print("No match among JSON names/alt_names.")

        print("Done: reached max requests.")
    except KeyboardInterrupt:
        print("\nStopped by user.")


if __name__ == "__main__":
    main()
