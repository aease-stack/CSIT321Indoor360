# nlp_preproc_syn.py
from __future__ import annotations
import re
from typing import List, Dict, Any, Optional, Tuple

# ------------------ Regex & maps ------------------
ARABIC_RE = re.compile(r'[\u0600-\u06FF]')
DIACRITICS_RE = re.compile(r'[\u064B-\u0652]')
ARABIC_DIGIT_MAP = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")
ALEF_MAP = str.maketrans({'أ':'ا','إ':'ا','آ':'ا','ٱ':'ا','ى':'ي','ؤ':'و','ئ':'ي'})
TATWEEL = "ـ"

def detect_lang(text: str) -> str:
    return "ar" if ARABIC_RE.search(text or "") else "en"

def fold_numbers(text: str) -> str:
    return (text or "").translate(ARABIC_DIGIT_MAP)

EN_WORD_NUM = {
    "one":1,"two":2,"three":3,"four":4,"five":5,"six":6,"seven":7,"eight":8,"nine":9,"ten":10,
}
def en_words_to_number(t: str) -> str:
    # longest first so "seven" before "one"
    for k in sorted(EN_WORD_NUM.keys(), key=len, reverse=True):
        t = re.sub(rf"\b{k}\b", str(EN_WORD_NUM[k]), t)
    return t

AR_ORD = {
    "الاول":1,"اول":1,"الأول":1,"الاولى":1,"اولى":1,
    "الثاني":2,"ثاني":2,"الثالث":3,"ثالث":3,"الرابع":4,"رابع":4,"الخامس":5,"خامس":5,
}
def ar_words_to_number(t: str) -> str:
    for k in sorted(AR_ORD.keys(), key=len, reverse=True):
        t = t.replace(k, str(AR_ORD[k]))
    return t

# Optional libs (we keep them soft; your app never breaks if missing)
_have_camel = False
_have_nltk  = False
try:
    from camel_tools.utils.dediac import dediac_ar
    from camel_tools.tokenizers.word import simple_word_tokenize as camel_tok
    _have_camel = True
except Exception:
    pass
try:
    import nltk
    nltk.download("punkt", quiet=True)
    nltk.download("stopwords", quiet=True)
    from nltk.corpus import stopwords as nltk_stopwords
    from nltk.tokenize import word_tokenize as nltk_tok
    from nltk.stem import PorterStemmer
    from nltk.stem.isri import ISRIStemmer
    _have_nltk = True
except Exception:
    nltk_stopwords = None
    nltk_tok = None
    PorterStemmer = None
    ISRIStemmer = None

class Preprocessor:
    def __init__(self, lang: str):
        self.lang = lang
        if _have_nltk:
            if lang == "en":
                try: self.stop_words = set(nltk_stopwords.words("english"))
                except Exception: self.stop_words = set()
                self.stemmer = PorterStemmer() if PorterStemmer else None
                self.tokenizer = nltk_tok if nltk_tok else (lambda s: s.split())
            elif lang == "ar":
                try: self.stop_words = set(nltk_stopwords.words("arabic"))
                except Exception: self.stop_words = set()
                self.stemmer = ISRIStemmer() if ISRIStemmer else None
                self.tokenizer = camel_tok if _have_camel else (lambda s: s.split())
            else:
                self.stop_words = set(); self.stemmer = None; self.tokenizer = lambda s: s.split()
        else:
            self.stop_words = set(); self.stemmer = None
            self.tokenizer = camel_tok if (_have_camel and lang=="ar") else (lambda s: s.split())

    def norm_ar(self, sent: str) -> str:
        t = (sent or "").strip().lower()
        t = fold_numbers(t)
        if _have_camel:
            try: t = dediac_ar(t)
            except Exception: t = DIACRITICS_RE.sub("", t)
        else:
            t = DIACRITICS_RE.sub("", t)
        t = t.replace(TATWEEL, "")
        t = t.translate(ALEF_MAP)
        t = t.replace("ة","ه")  # tie ta to ha
        t = re.sub(r"[^\w\s/.-]", " ", t)
        t = re.sub(r"\s+", " ", t).strip()
        t = ar_words_to_number(t)
        return t

    def norm_en(self, sent: str) -> str:
        t = (sent or "").strip().lower()
        t = re.sub(r"[^\w\s/.-]", " ", t)
        t = re.sub(r"\s+", " ", t).strip()
        t = en_words_to_number(t)
        return t

    def norm_any(self, sent: str) -> str:
        return self.norm_ar(sent) if self.lang == "ar" else self.norm_en(sent)

    def pipeline(self, sent: str) -> List[str]:
        t = self.norm_any(sent)
        toks = t.split()
        if self.lang == "ar":
            toks = [w[2:] if w.startswith("ال") else w for w in toks]
        return toks

# -------------- Canonical families (numbered) --------------
NUMBERED_BASES = ["meeting room", "war room", "quiet room", "elevator", "phone booth", "restroom"]
FAMILYABLE_BASES = set(NUMBERED_BASES)

# -------------- Synonyms (incl. variants you reported) --------------
RAW_CANON_SYNONYM = {
    # --- Restroom family ---
    "restroom":"restroom","restrooms":"restroom","rest room":"restroom",
    "bathroom":"restroom","bath room":"restroom","toilet":"restroom","toilets":"restroom",
    "wc":"restroom","washroom":"restroom","wash room":"restroom",
    "حمام":"restroom","الحمام":"restroom","حمامات":"restroom",
    "دورة المياه":"restroom","دورات المياه":"restroom","مرحاض":"restroom",
    "باثروم":"restroom","باتروم":"restroom","بتروم":"restroom","هامام":"restroom",

    # --- Elevator / Lift ---
    "elevator":"elevator","lift":"elevator","لفت":"elevator",
    "مصعد":"elevator","اسانسير":"elevator","أسانسير":"elevator","اصنصير":"elevator",

    # --- Meeting ---
    "meeting":"meeting room","meetings":"meeting room","meeting room":"meeting room",
    "اجتماع":"meeting room","اجتماعات":"meeting room","غرفة الاجتماعات":"meeting room","غرفه الاجتماعات":"meeting room",
    "ميتينج":"meeting room","ميتينق":"meeting room","ميتنق":"meeting room",

    # --- Quiet ---
    "quiet":"quiet room","quiet room":"quiet room","white room":"quiet room",
    "وايت روم":"quiet room","كوايت":"quiet room","قوايت":"quiet room","غرفة هادئة":"quiet room","غرفه هادئه":"quiet room",
    "وايت":"quiet room","هاديه":"quiet room",

    # --- War ---
    "war":"war room","war room":"war room","وير روم":"war room","وور روم":"war room",
    "غرفة حرب":"war room","غرفه حرب":"war room","غرفة القيادة":"war room","غرفه القياده":"war room",

    # --- Phone booth ---
    "booth":"phone booth","phone":"phone booth","phone booth":"phone booth","فون بوث":"phone booth","بوث":"phone booth","phone boss":"phone booth",

    # --- Control / Others ---
    "control":"control room","control room":"control room","كنترول روم":"control room","كونترول روم":"control room","غرفة التحكم":"control room","غرفه التحكم":"control room",
    "theatre":"theatre","theater":"theatre","مسرح":"theatre",
    "studio":"studio","استديو":"studio","ستوديو":"studio","استوديو":"studio",
    "luggage":"luggage storage","luggage storage":"luggage storage","luggage store":"luggage storage","luggage room":"luggage storage","تخزين الحقائب":"luggage storage",
    "board":"board room","board room":"board room","بورد روم":"board room",
    "idf":"idf room","idf room":"idf room","server room":"idf room","غرفة الشبكات":"idf room","سيرفر روم":"idf room",
    "production":"production room","production room":"production room","غرفة الانتاج":"production room","غرفه الانتاج":"production room",
    "testing":"testing room","testing room":"testing room","غرفة الاختبار":"testing room","غرفه الاختبار":"testing room",
    "store":"store room","store room":"store room","storage room":"store room","مخزن":"store room","ستور روم":"store room",
    "emerging tech lab":"emerging tech lab","innovation lab":"emerging tech lab","lab":"emerging tech lab","لاب":"emerging tech lab",
    "raised area":"raised area","difference area":"difference area",
    "reception":"reception / cafe","cafe":"reception / cafe","coffee":"reception / cafe","ريسبشن":"reception / cafe","كوفي":"reception / cafe",
}

def norm_json_name(s: str) -> str:
    if not s: return ""
    t = (s or "").strip().lower()
    t = t.translate(ALEF_MAP).replace("ة","ه")
    t = t.replace("rest room", "restroom")       # unify
    t = re.sub(r"[^\w\s/.-]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    # "restroom1" → "restroom 1"; same for Arabic words + digits
    t = re.sub(r'([a-z\u0600-\u06FF]+)\s*(\d+)$', r'\1 \2', t)
    return t

def _expand_numbered_variants(base: str, available: set) -> Dict[str, str]:
    out = {}
    for n in range(1, 200):
        cand = f"{base} {n}"
        if cand in available:
            out[cand] = cand
    return out

def build_family_catalog(available: set) -> Dict[str, List[str]]:
    fams: Dict[str, List[str]] = {b: [] for b in FAMILYABLE_BASES}
    for nn in available:
        for b in FAMILYABLE_BASES:
            if nn.startswith(b + " "):
                fams[b].append(nn)
    def keyer(x: str):
        m = re.findall(r"\d+", x)
        return int(m[0]) if m else 10**9
    for b in fams:
        fams[b].sort(key=keyer)
    return fams

def build_json_lookup(units: List[Dict[str, Any]]) -> Dict[str, Any]:
    norm_to_original: Dict[str, str] = {}
    substr_list: List[Tuple[str, str]] = []

    for u in units:
        nm = u.get("name")
        if nm:
            nn = norm_json_name(nm)
            if nn:
                norm_to_original[nn] = nm
                substr_list.append((nn, nm))
        alt = u.get("alt_name")
        if alt:
            na = norm_json_name(alt)
            if na:
                norm_to_original[na] = alt
                substr_list.append((na, alt))

    available = set(norm_to_original.keys())

    # Register base families (e.g., "restroom") if any member exists (e.g., "restroom 1/2")
    for b in FAMILYABLE_BASES:
        if any(nm.startswith(b + " ") for nm in available):
            available.add(b)

    numbered_maps = {base: _expand_numbered_variants(base, available) for base in NUMBERED_BASES}

    def _norm_key(k: str) -> str:
        if detect_lang(k) == "ar":
            t = (k or "").strip().lower()
            t = fold_numbers(t)
            t = DIACRITICS_RE.sub("", t).replace(TATWEEL, "")
            t = t.translate(ALEF_MAP).replace("ة","ه")
        else:
            t = (k or "").strip().lower()
        t = re.sub(r"[^\w\s/.-]", " ", t)
        t = re.sub(r"\s+", " ", t).strip()
        return t

    canon_syn_norm: Dict[str, str] = {}
    for k, v in RAW_CANON_SYNONYM.items():
        canon_syn_norm[_norm_key(k)] = v

    family_catalog = build_family_catalog(available)

    return {
        "norm_to_original": norm_to_original,
        "substr_list": substr_list,
        "available": available,
        "numbered_maps": numbered_maps,
        "canon_syn_norm": canon_syn_norm,
        "family_catalog": family_catalog,
    }

AR_NUM_CAPTURE = re.compile(r'(?:حمام|غرف(?:ه|ة)\s*الاجتماعات|ميتينج|ميتينق|ميتنق|روم|مصعد|بوث)\s*(?:ال)?(?:رقم\s*)?(\d+)')
EN_NUM_CAPTURE = re.compile(r'\b(\d{1,3})\b')

def _lev(a: str, b: str) -> int:
    if a == b: return 0
    if not a: return len(b)
    if not b: return len(a)
    prev = list(range(len(b)+1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cost = 0 if ca == cb else 1
            cur.append(min(prev[j] + 1, cur[-1] + 1, prev[j-1] + cost))
        prev = cur
    return prev[-1]

def _apply_synonyms_or_base(q: str, lookup: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    avail = lookup["available"]
    canon_map = lookup["canon_syn_norm"]

    # Exact synonym to base?
    if q in canon_map:
        canon = canon_map[q]          # e.g., 'restroom'
        # If user said just the base, return family
        if canon in avail and canon not in lookup["norm_to_original"]:
            return None, canon

        # If the base itself is also a concrete name in JSON (rare), return it
        if canon in lookup["norm_to_original"]:
            return canon, None

    # Synonym contains a number? (e.g., "restroom 1", "حمام ١")
    for base in lookup["numbered_maps"].keys():
        if base in q or (q in canon_map and canon_map[q] == base):
            m = EN_NUM_CAPTURE.search(q) or AR_NUM_CAPTURE.search(q)
            if m:
                n = int(m.group(1))
                cand = f"{base} {n}"
                if cand in lookup["available"]:
                    return cand, None
                # allow even if not pre-registered; we’ll handle later
                return cand, None
    return None, None

def _reconstruct_numbered(q: str, lookup: Dict[str, Any]) -> Optional[str]:
    avail = lookup["available"]
    for base in lookup["numbered_maps"].keys():
        if base in q:
            m = re.search(rf"{re.escape(base)}\s+(\d{{1,3}})", q)
            if m:
                n = int(m.group(1))
                cand = f"{base} {n}"
                if cand in avail: return cand
    m_ar = AR_NUM_CAPTURE.search(q)
    if m_ar:
        n = int(m_ar.group(1))
        for base in lookup["numbered_maps"].keys():
            cand = f"{base} {n}"
            if cand in avail: return cand
    return None

def match_json_name_or_family(text: str, lookup: Dict[str, Any],
                              ar_pre: Preprocessor, en_pre: Preprocessor,
                              jaccard_min: float = 0.36, max_lev_ratio: float = 0.22
                              ) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    if not text or not lookup:
        return None, None
    q = ar_pre.norm_any(text) if detect_lang(text) == "ar" else en_pre.norm_any(text)

    # 1) synonyms / base
    concrete, base = _apply_synonyms_or_base(q, lookup)
    if concrete and (concrete in lookup["norm_to_original"] or concrete in lookup["available"]):
        # accept even if 'available' only (we’ll map to original later)
        return {"name": lookup["norm_to_original"].get(concrete, concrete), "norm": concrete, "score": 1.0}, None
    if base and base in lookup["family_catalog"]:
        opts = lookup["family_catalog"][base]
        if not opts:
            return None, {"family": base, "options": []}
        if len(opts) == 1:
            only = opts[0]
            return {"name": lookup["norm_to_original"][only], "norm": only, "score": 1.0}, None
        return None, {"family": base, "options": [lookup["norm_to_original"][o] for o in opts]}

    # 2) reconstruct numbered from free form
    rec = _reconstruct_numbered(q, lookup)
    if rec and rec in lookup["norm_to_original"]:
        return {"name": lookup["norm_to_original"][rec], "norm": rec, "score": 1.0}, None

    # 3) substring / exact
    for nn, _orig in lookup["substr_list"]:
        if nn == q or nn in q:
            return {"name": lookup["norm_to_original"][nn], "norm": nn, "score": 1.0}, None

    # 4) token Jaccard + small Levenshtein
    def pipe_tokens(s: str) -> List[str]:
        p = ar_pre if detect_lang(s) == "ar" else en_pre
        return p.pipeline(s)
    q_tokens = pipe_tokens(q)
    best: Tuple[float, str] = (0.0, "")
    for nn, _orig in lookup["substr_list"]:
        name_toks = pipe_tokens(nn)
        sa, sb = set(q_tokens), set(name_toks)
        jac = (len(sa & sb) / (len(sa | sb) or 1)) if (sa or sb) else 0.0
        if jac > best[0]:
            best = (jac, nn)
    if best[0] >= jaccard_min:
        nn = best[1]
        dist = _lev(q, nn)
        max_allow = int(max(len(q), len(nn)) * max_lev_ratio)
        if dist <= max_allow:
            return {"name": lookup["norm_to_original"][nn], "norm": nn, "score": best[0]}, None

    return None, None
