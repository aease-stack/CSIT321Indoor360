import os
import json
import zipfile
import psycopg2
import traceback

# === CONFIG ===
IMDF_ZIP = r"C:\Users\hhs39\OneDrive - University of Wollongong\Desktop\1\.vscode\IMDF_Mon_07_Jul_2025_09_12_01_GMT.zip"
EXTRACT_DIR = "./imdf_extracted"

DB_CONFIG = {
    "dbname": "INDOOR",
    "user": "postgres",
    "password": "root",
    "host": "localhost",
    "port": "5432"
}

def main():
    try:
        os.makedirs(EXTRACT_DIR, exist_ok=True)

        # 1) extract IMDF zip
        with zipfile.ZipFile(IMDF_ZIP, "r") as z:
            files = z.namelist()
            print("Files inside ZIP:", files)
            z.extractall(EXTRACT_DIR)

        # 2) connect to DB
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()

        # 3) insert into imdf_packages
        package_name = os.path.splitext(os.path.basename(IMDF_ZIP))[0]
        cur.execute("""
            INSERT INTO imdf_packages (name, version, uploaded_by)
            VALUES (%s, %s, %s)
            RETURNING package_id
        """, (package_name, "1.0", None))
        package_id = cur.fetchone()[0]
        conn.commit()
        print(f"Inserted package: {package_id}, {package_name}")

        # 4) insert JSON/GeoJSON files into imdf_files
        inserted = 0
        for fname in os.listdir(EXTRACT_DIR):
            if not fname.lower().endswith((".json", ".geojson")):
                continue

            fpath = os.path.join(EXTRACT_DIR, fname)
            with open(fpath, "r", encoding="utf-8") as fh:
                data = json.load(fh)

            cur.execute("""
                INSERT INTO imdf_files (package_id, file_name, data)
                VALUES (%s, %s, %s)
            """, (package_id, fname, json.dumps(data)))
            inserted += 1

        conn.commit()
        print(f"Inserted {inserted} JSON/GeoJSON files into imdf_files")

        # 5) call IMDF import functions
        for fn in ("import_imdf_buildings", "import_imdf_floors", "import_imdf_pois", "import_imdf_routes"):
            try:
                cur.execute(f"SELECT {fn}(%s);", (package_id,))
                print(f"Called {fn}({package_id})")
            except Exception as e:
                print(f" Warning: calling {fn} failed: {e}")

        conn.commit()
        print("IMDF import completed successfully.")

    except Exception:
        print(" ERROR during import:")
        traceback.print_exc()
    finally:
        try:
            cur.close()
            conn.close()
        except:
            pass

if __name__ == "__main__":
    main()
